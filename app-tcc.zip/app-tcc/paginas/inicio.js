import React, { useState } from 'react';

import { Text, View, TouchableOpacity, TextInput } from 'react-native';
import Style from '../styles/styleInicio';

export default function Login({ navigation }: any) {

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const isValidEmail = (value: string) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);

  return (
    <View style={Style.container}>
      <View style={Style.card}>

        <Text style={Style.title}>Bem-vindo!</Text>
        <Text style={Style.subtitle}>Faça login para continuar</Text>

        <TextInput
          style={Style.input}
          placeholder="Email"
          placeholderTextColor='gray'
          value={email}
          onChangeText={setEmail}
        />

        {email.length > 0 && !isValidEmail(email) && (
          <Text style={Style.error}>Email inválido</Text>
        )}

        <TextInput
          style={Style.input}
          placeholder="Senha"
          placeholderTextColor='gray'
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />

        <TouchableOpacity style={Style.button}>
          <Text style={Style.buttonText}>Entrar</Text>
        </TouchableOpacity>

        <View style={Style.link}>
          <Text style={{ color: 'white', marginTop: 15 }}>Não tem conta?</Text>
          <TouchableOpacity
            onPress={() => navigation.navigate('cadastro')}
          >
            <Text style={{ color: 'white', marginTop: 15, paddingLeft: 5 }}>
              Criar conta
            </Text>
          </TouchableOpacity>
        </View>

      </View>
    </View>
  );
}