import React, { useState } from 'react';
import { Text, View, TouchableOpacity, TextInput, ScrollView } from 'react-native';
import Style from '../styles/styleCadastro';

export default function Register({ navigation }: any) {

  const [nome, setNome] = useState('');
  const [telefone, setTelefone] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [nascimento, setNascimento] = useState('');

  const isValidEmail = (value: string) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);

  const handleTelefone = (text: string) => {
    let cleaned = text.replace(/\D/g, '');
    if (cleaned.length > 11) cleaned = cleaned.slice(0, 11);
    let formatted = cleaned;
    if (cleaned.length > 2) {
      formatted = `(${cleaned.slice(0, 2)}) ${cleaned.slice(2)}`;
    }
    if (cleaned.length > 7) {
      formatted = `(${cleaned.slice(0, 2)}) ${cleaned.slice(2, 7)}-${cleaned.slice(7)}`;
    }

    setTelefone(formatted);
  };

  const handleNascimento = (text: string) => {
    let cleaned = text.replace(/\D/g, '');
    if (cleaned.length > 8) cleaned = cleaned.slice(0, 8);
    let formatted = cleaned;
    if (cleaned.length > 2) {
      formatted = cleaned.slice(0, 2) + '/' + cleaned.slice(2);
    }
    if (cleaned.length > 4) {
      formatted =
        cleaned.slice(0, 2) +
        '/' +
        cleaned.slice(2, 4) +
        '/' +
        cleaned.slice(4);
    }

    setNascimento(formatted);
  };

  return (
    <ScrollView>
    <View style={Style.container}>
      <View style={Style.card}>

        <Text style={Style.title}>Criar Conta</Text>
        <Text style={Style.subtitle}>Preencha as informações</Text>

        {/* NOME */}
        <Text style={Style.topico}>Nome:</Text>
        <TextInput
          style={Style.input}
          value={nome}
          onChangeText={setNome}
        />

        {/* TELEFONE */}
        <Text style={Style.topico}>Telefone:</Text>
        <TextInput
          style={Style.input}
          placeholder="(11) 99999-9999"
          placeholderTextColor="gray"
          value={telefone}
          onChangeText={handleTelefone}
          keyboardType="numeric"
        />

        {/* NASCIMENTO */}
        <Text style={Style.topico}>Data de nascimento:</Text>
        <TextInput
          style={Style.input}
          placeholder="DD/MM/AAAA"
          placeholderTextColor="gray"
          value={nascimento}
          onChangeText={handleNascimento}
          keyboardType="numeric"
        />

        {/* EMAIL */}
        <Text style={Style.topico}>Email:</Text>
        <TextInput
          style={Style.input}
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
        />

        {email.length > 0 && !isValidEmail(email) && (
          <Text style={Style.error}>Email inválido</Text>
        )}

        {/* SENHA */}
        <Text style={Style.topico}>Senha:</Text>
        <TextInput
          style={Style.input}
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />

        <TouchableOpacity style={Style.button}>
          <Text style={Style.buttonText}>Cadastrar</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={{ color: '#94a3b8', marginTop: 15 }}>
            Já tem conta? Entrar
          </Text>
        </TouchableOpacity>

      </View>
    </View>
    </ScrollView>
  );
}