import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#d0f1df',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },

  card: {
    width: '100%',
    maxWidth: 420,
    backgroundColor: '#96c6a5',
    padding: 25,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 8,
  },

  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 5,
  },

  subtitle: {
    color: 'white',
    marginBottom: 20,
  },

  input: {
    backgroundColor: '#e3fff2',
    borderWidth: 1,
    borderColor: '#334155',
    borderRadius: 10,
    padding: 12,
    marginBottom: 10,
    color: 'black',
  },

  error: {
    color: '#ef4444',
    marginBottom: 10,
    fontSize: 12,
  },

  button: {
    backgroundColor: '#aad4b9',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 25,
  },

  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },

  link: {
    display: 'flex',
    flexDirection: 'row'
  },

  topico: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 17,
    paddingTop: 10
  }
});