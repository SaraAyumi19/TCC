import React, {
  useEffect,
  useState,
  useCallback,
} from "react";

import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  Modal,
  ScrollView,
  Image,
  ActivityIndicator,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";

import {
  useNavigation,
  useFocusEffect,
} from "@react-navigation/native";

import { supabase } from "../lib/supabase";

import Style from "../styles/styles";

export default function Page1() {
  const navigation = useNavigation();

  // =====================================================
  // ESTADOS
  // =====================================================

  const [city, setCity] = useState("");

  const [menuVisible, setMenuVisible] =
    useState(false);

  const [cidadeEncontrada, setCidadeEncontrada] =
    useState(null);

  const [previsaoAmanha, setPrevisaoAmanha] =
    useState(null);

  const [avatarUrl, setAvatarUrl] =
    useState(null);

  const [name, setName] =
    useState("");

  const [loading, setLoading] =
    useState(false);

  const [erro, setErro] =
    useState("");

  // =====================================================
  // CARREGAR USUÁRIO
  // =====================================================

  async function carregarUsuario() {
    try {
      const {
        data: { user },
        error,
      } = await supabase.auth.getUser();

      if (error) {
        console.log(
          "Erro ao carregar usuário:",
          error
        );

        return;
      }

      if (!user) {
        console.log(
          "Nenhum usuário encontrado."
        );

        return;
      }

      console.log(
        "Usuário:",
        user.id
      );

      console.log(
        "Avatar:",
        user.user_metadata?.avatar_url
      );

      setName(
        user.user_metadata?.name || ""
      );

      const avatar =
        user.user_metadata?.avatar_url;

      if (avatar) {
        // Adiciona timestamp para evitar cache
        const novaUrl =
          avatar.includes("?")
            ? `${avatar}&t=${Date.now()}`
            : `${avatar}?t=${Date.now()}`;

        setAvatarUrl(novaUrl);
      } else {
        setAvatarUrl(null);
      }

    } catch (error) {
      console.log(
        "Erro:",
        error
      );
    }
  }

  // =====================================================
  // ATUALIZAR QUANDO VOLTAR PARA PAGE1
  // =====================================================

  useFocusEffect(
    useCallback(() => {
      carregarUsuario();

      return () => {};
    }, [])
  );

  // =====================================================
  // BUSCAR CIDADE E CLIMA
  // =====================================================

  async function searchCity() {
    if (!city.trim()) {
      setErro(
        "Digite o nome de uma cidade."
      );

      return;
    }

    setLoading(true);
    setErro("");

    setCidadeEncontrada(null);
    setPrevisaoAmanha(null);

    try {
      // =================================================
      // CHAVE OPENWEATHER
      // =================================================

      const key =
        "e0a40fe2984aaeec66defdc668107d65";

      // =================================================
      // GEOCODING
      // =================================================

      const geoUrl =
        `https://api.openweathermap.org/geo/1.0/direct` +
        `?q=${encodeURIComponent(
          city.trim()
        )},BR` +
        `&limit=1` +
        `&appid=${key}`;

      console.log(
        "Buscando cidade..."
      );

      const geoResponse =
        await fetch(geoUrl);

      const geoData =
        await geoResponse.json();

      console.log(
        "Cidade:",
        geoData
      );

      if (!geoResponse.ok) {
        throw new Error(
          geoData.message ||
            "Erro ao buscar cidade."
        );
      }

      if (
        !geoData ||
        geoData.length === 0
      ) {
        throw new Error(
          "Cidade não encontrada."
        );
      }

      const cidade =
        geoData[0];

      setCidadeEncontrada(
        cidade
      );

      const latitude =
        cidade.lat;

      const longitude =
        cidade.lon;

      // =================================================
      // PREVISÃO
      // =================================================

      const forecastUrl =
        `https://api.openweathermap.org/data/2.5/forecast` +
        `?lat=${latitude}` +
        `&lon=${longitude}` +
        `&appid=${key}` +
        `&units=metric` +
        `&lang=pt_br`;

      console.log(
        "Buscando previsão..."
      );

      const forecastResponse =
        await fetch(
          forecastUrl
        );

      const forecastData =
        await forecastResponse.json();

      console.log(
        "Previsão:",
        forecastData
      );

      if (!forecastResponse.ok) {
        throw new Error(
          forecastData.message ||
            "Erro ao buscar previsão."
        );
      }

      // =================================================
      // CALCULAR AMANHÃ
      // =================================================

      const hoje =
        new Date();

      const amanha =
        new Date(hoje);

      amanha.setDate(
        hoje.getDate() + 1
      );

      const ano =
        amanha.getFullYear();

      const mes =
        String(
          amanha.getMonth() + 1
        ).padStart(2, "0");

      const dia =
        String(
          amanha.getDate()
        ).padStart(2, "0");

      const dataAmanha =
        `${ano}-${mes}-${dia}`;

      // =================================================
      // FILTRAR PREVISÕES DE AMANHÃ
      // =================================================

      const previsoesAmanha =
        forecastData.list.filter(
          (item) => {
            const data =
              new Date(
                item.dt * 1000
              );

            const itemAno =
              data.getFullYear();

            const itemMes =
              String(
                data.getMonth() + 1
              ).padStart(2, "0");

            const itemDia =
              String(
                data.getDate()
              ).padStart(2, "0");

            const dataItem =
              `${itemAno}-${itemMes}-${itemDia}`;

            return (
              dataItem ===
              dataAmanha
            );
          }
        );

      if (
        previsoesAmanha.length === 0
      ) {
        throw new Error(
          "Não foi possível encontrar a previsão para amanhã."
        );
      }

      // =================================================
      // TEMPERATURA
      // =================================================

      const temperaturas =
        previsoesAmanha.map(
          (item) =>
            item.main.temp
        );

      const temperaturaMin =
        Math.min(
          ...temperaturas
        );

      const temperaturaMax =
        Math.max(
          ...temperaturas
        );

      // =================================================
      // CHUVA
      // =================================================

      const chuva =
        previsoesAmanha.reduce(
          (total, item) => {
            return (
              total +
              (item.rain?.["3h"] || 0)
            );
          },
          0
        );

      // =================================================
      // PROBABILIDADE DE CHUVA
      // =================================================

      const probabilidades =
        previsoesAmanha.map(
          (item) =>
            (item.pop || 0) * 100
        );

      const probabilidadeChuva =
        Math.max(
          ...probabilidades
        );

      // =================================================
      // UMIDADE
      // =================================================

      const umidades =
        previsoesAmanha.map(
          (item) =>
            item.main.humidity
        );

      const umidadeMedia =
        umidades.reduce(
          (a, b) =>
            a + b,
          0
        ) /
        umidades.length;

      // =================================================
      // VENTO
      // =================================================

      const ventos =
        previsoesAmanha.map(
          (item) =>
            item.wind?.speed || 0
        );

      const ventoMax =
        Math.max(
          ...ventos
        );

      // =================================================
      // CONDIÇÃO DO TEMPO
      // =================================================

      const condicao =
        previsoesAmanha[0]
          ?.weather?.[0]
          ?.description ||
        "Sem informação";

      // =================================================
      // SALVAR
      // =================================================

      setPrevisaoAmanha({
        data: amanha,

        temperaturaMin:
          temperaturaMin,

        temperaturaMax:
          temperaturaMax,

        chuva:
          chuva,

        probabilidadeChuva:
          probabilidadeChuva,

        umidadeMedia:
          umidadeMedia,

        ventoMax:
          ventoMax,

        condicao:
          condicao,
      });

    } catch (error) {
      console.log(
        "ERRO:",
        error
      );

      setErro(
        error?.message ||
          "Não foi possível buscar a previsão."
      );

    } finally {
      setLoading(false);
    }
  }

  // =====================================================
  // FORMATAR DATA
  // =====================================================

  function formatarData(data) {
    return data.toLocaleDateString(
      "pt-BR",
      {
        weekday: "long",
        day: "2-digit",
        month: "long",
      }
    );
  }

  // =====================================================
  // TELA
  // =====================================================

  return (
    <View
      style={Style.container}
    >

      {/* =================================================
          CABEÇALHO
      ================================================= */}

      <View
        style={Style.header}
      >

        {/* MENU */}

        <TouchableOpacity
          onPress={() =>
            setMenuVisible(true)
          }
          style={
            Style.headerButton
          }
        >
          <Ionicons
            name="menu-outline"
            size={30}
            color="#3F5535"
          />
        </TouchableOpacity>

        {/* TÍTULO */}

        <Text
          style={Style.titulo}
        >
          Clima agrícola
        </Text>

        {/* PERFIL */}

        <TouchableOpacity
          onPress={() =>
            navigation.navigate(
              "Perfil"
            )
          }
          style={{
            width: 48,
            height: 48,
            borderRadius: 24,
            backgroundColor:
              "#D9CEBD",
            justifyContent:
              "center",
            alignItems:
              "center",
            overflow:
              "hidden",
          }}
        >

          {avatarUrl ? (
            <Image
              source={{
                uri: avatarUrl,
              }}
              style={{
                width: 48,
                height: 48,
              }}
              resizeMode="cover"
            />
          ) : (
            <Ionicons
              name="person"
              size={27}
              color="#3F5535"
            />
          )}

        </TouchableOpacity>

      </View>

      {/* =================================================
          MENU
      ================================================= */}

      <Modal
        visible={
          menuVisible
        }
        transparent
        animationType="fade"
        onRequestClose={() =>
          setMenuVisible(false)
        }
      >

        <TouchableOpacity
          style={
            Style.modalFundo
          }
          activeOpacity={1}
          onPress={() =>
            setMenuVisible(false)
          }
        >

          <View
            style={
              Style.menuContainer
            }
          >

            <Text
              style={
                Style.menuTitulo
              }
            >
              Menu
            </Text>

            {/* INÍCIO */}

            <TouchableOpacity
              style={
                Style.menuItem
              }
              onPress={() => {
                setMenuVisible(
                  false
                );

                navigation.navigate(
                  "Page1"
                );
              }}
            >

              <Ionicons
                name="home-outline"
                size={22}
                color="#526B45"
              />

              <Text
                style={
                  Style.menuTexto
                }
              >
                Início
              </Text>

            </TouchableOpacity>

            {/* PAGE 2 */}

            <TouchableOpacity
              style={
                Style.menuItem
              }
              onPress={() => {
                setMenuVisible(
                  false
                );

                navigation.navigate(
                  "Page2"
                );
              }}
            >

              <Ionicons
                name="leaf-outline"
                size={22}
                color="#526B45"
              />

              <Text
                style={
                  Style.menuTexto
                }
              >
                Página 2
              </Text>

            </TouchableOpacity>

            {/* PAGE 3 */}

            <TouchableOpacity
              style={
                Style.menuItem
              }
              onPress={() => {
                setMenuVisible(
                  false
                );

                navigation.navigate(
                  "Page3"
                );
              }}
            >

              <Ionicons
                name="settings-outline"
                size={22}
                color="#526B45"
              />

              <Text
                style={
                  Style.menuTexto
                }
              >
                Página 3
              </Text>

            </TouchableOpacity>

            {/* PERFIL */}

            <TouchableOpacity
              style={
                Style.menuItem
              }
              onPress={() => {
                setMenuVisible(
                  false
                );

                navigation.navigate(
                  "Perfil"
                );
              }}
            >

              <Ionicons
                name="person-outline"
                size={22}
                color="#526B45"
              />

              <Text
                style={
                  Style.menuTexto
                }
              >
                Meu perfil
              </Text>

            </TouchableOpacity>

          </View>

        </TouchableOpacity>

      </Modal>

      {/* =================================================
          CONTEÚDO
      ================================================= */}

      <ScrollView
        contentContainerStyle={{
          alignItems:
            "center",
          paddingBottom:
            40,
        }}
      >

        {/* TÍTULO */}

        <View
          style={{
            width: "90%",
            marginTop: 25,
          }}
        >

          <Text
            style={{
              fontSize: 27,
              fontWeight:
                "bold",
              color:
                "#3D3026",
            }}
          >
            Previsão de amanhã
          </Text>

          <Text
            style={{
              marginTop: 5,
              color:
                "#6B5848",
              fontSize: 15,
            }}
          >
            Informações importantes
            para sua produção
          </Text>

        </View>

        {/* =================================================
            BUSCA
        ================================================= */}

        <View
          style={{
            width: "90%",
            marginTop: 20,
          }}
        >

          <TextInput
            style={
              Style.cidade
            }
            value={city}
            onChangeText={
              setCity
            }
            placeholder="Digite a cidade"
            placeholderTextColor="#8A7A69"
            onSubmitEditing={
              searchCity
            }
          />

          <TouchableOpacity
            onPress={
              searchCity
            }
            style={
              Style.botao
            }
            disabled={
              loading
            }
          >

            {loading ? (
              <ActivityIndicator
                color="white"
              />
            ) : (
              <Text
                style={{
                  color:
                    "white",
                  fontWeight:
                    "bold",
                }}
              >
                Buscar previsão
              </Text>
            )}

          </TouchableOpacity>

        </View>

        {/* =================================================
            ERRO
        ================================================= */}

        {erro !== "" && (
          <Text
            style={{
              color:
                "#B94A48",
              marginTop: 15,
              width: "90%",
              textAlign:
                "center",
            }}
          >
            {erro}
          </Text>
        )}

        {/* =================================================
            CIDADE
        ================================================= */}

        {cidadeEncontrada && (
          <View
            style={{
              width: "90%",
              marginTop: 25,
            }}
          >

            <Text
              style={{
                fontSize: 24,
                fontWeight:
                  "bold",
                color:
                  "#3D3026",
              }}
            >
              {
                cidadeEncontrada.name
              }
            </Text>

            <Text
              style={{
                color:
                  "#6B5848",
                marginTop: 3,
              }}
            >
              {
                cidadeEncontrada.state ||
                ""
              }

              {
                cidadeEncontrada.state
                  ? " - "
                  : ""
              }

              Brasil
            </Text>

          </View>
        )}

        {/* =================================================
            PREVISÃO DE AMANHÃ
        ================================================= */}

        {previsaoAmanha && (
          <View
            style={{
              width: "90%",
              marginTop: 20,
            }}
          >

            {/* DATA */}

            <View
              style={{
                backgroundColor:
                  "#526B45",
                padding: 18,
                borderRadius: 20,
              }}
            >

              <Text
                style={{
                  color:
                    "white",
                  fontSize: 18,
                  fontWeight:
                    "bold",
                  textTransform:
                    "capitalize",
                }}
              >
                {formatarData(
                  previsaoAmanha.data
                )}
              </Text>

              <Text
                style={{
                  color:
                    "#E4EBD8",
                  marginTop: 5,
                }}
              >
                Previsão para amanhã
              </Text>

            </View>

            {/* =================================================
                TEMPERATURA
            ================================================= */}

            <View
              style={{
                backgroundColor:
                  "white",
                marginTop: 15,
                padding: 20,
                borderRadius: 20,
              }}
            >

              <Text
                style={{
                  color:
                    "#6B5848",
                  fontSize: 16,
                }}
              >
                🌡️ Temperatura
              </Text>

              <View
                style={{
                  flexDirection:
                    "row",
                  justifyContent:
                    "space-around",
                  marginTop: 15,
                }}
              >

                <View
                  style={{
                    alignItems:
                      "center",
                  }}
                >

                  <Text
                    style={{
                      fontSize: 30,
                      fontWeight:
                        "bold",
                      color:
                        "#526B45",
                    }}
                  >
                    {Math.round(
                      previsaoAmanha
                        .temperaturaMin
                    )}
                    °C
                  </Text>

                  <Text
                    style={{
                      color:
                        "#777",
                    }}
                  >
                    Mínima
                  </Text>

                </View>

                <View
                  style={{
                    alignItems:
                      "center",
                  }}
                >

                  <Text
                    style={{
                      fontSize: 30,
                      fontWeight:
                        "bold",
                      color:
                        "#B46B3C",
                    }}
                  >
                    {Math.round(
                      previsaoAmanha
                        .temperaturaMax
                    )}
                    °C
                  </Text>

                  <Text
                    style={{
                      color:
                        "#777",
                    }}
                  >
                    Máxima
                  </Text>

                </View>

              </View>

            </View>

            {/* =================================================
                CHUVA
            ================================================= */}

            <View
              style={{
                backgroundColor:
                  "white",
                marginTop: 12,
                padding: 20,
                borderRadius: 20,
              }}
            >

              <Text
                style={{
                  color:
                    "#6B5848",
                  fontSize: 16,
                }}
              >
                🌧️ Chuva
              </Text>

              <Text
                style={{
                  fontSize: 27,
                  fontWeight:
                    "bold",
                  color:
                    "#526B45",
                  marginTop: 10,
                }}
              >
                {
                  previsaoAmanha.chuva.toFixed(
                    1
                  )
                }{" "}
                mm
              </Text>

              <Text
                style={{
                  color:
                    "#777",
                  marginTop: 4,
                }}
              >
                Probabilidade máxima:{" "}
                {Math.round(
                  previsaoAmanha
                    .probabilidadeChuva
                )}
                %
              </Text>

            </View>

            {/* =================================================
                UMIDADE
            ================================================= */}

            <View
              style={{
                backgroundColor:
                  "white",
                marginTop: 12,
                padding: 20,
                borderRadius: 20,
              }}
            >

              <Text
                style={{
                  color:
                    "#6B5848",
                  fontSize: 16,
                }}
              >
                💧 Umidade
              </Text>

              <Text
                style={{
                  fontSize: 27,
                  fontWeight:
                    "bold",
                  color:
                    "#526B45",
                  marginTop: 10,
                }}
              >
                {Math.round(
                  previsaoAmanha
                    .umidadeMedia
                )}
                %
              </Text>

              <Text
                style={{
                  color:
                    "#777",
                  marginTop: 4,
                }}
              >
                Umidade média prevista
              </Text>

            </View>

            {/* =================================================
                VENTO
            ================================================= */}

            <View
              style={{
                backgroundColor:
                  "white",
                marginTop: 12,
                padding: 20,
                borderRadius: 20,
              }}
            >

              <Text
                style={{
                  color:
                    "#6B5848",
                  fontSize: 16,
                }}
              >
                💨 Vento
              </Text>

              <Text
                style={{
                  fontSize: 27,
                  fontWeight:
                    "bold",
                  color:
                    "#526B45",
                  marginTop: 10,
                }}
              >
                {
                  previsaoAmanha.ventoMax.toFixed(
                    1
                  )
                }{" "}
                m/s
              </Text>

              <Text
                style={{
                  color:
                    "#777",
                  marginTop: 4,
                }}
              >
                Velocidade máxima prevista
              </Text>

            </View>

            {/* =================================================
                CONDIÇÃO DO TEMPO
            ================================================= */}

            <View
              style={{
                backgroundColor:
                  "#E4EBD8",
                marginTop: 12,
                padding: 20,
                borderRadius: 20,
              }}
            >

              <Text
                style={{
                  color:
                    "#3D3026",
                  fontSize: 16,
                }}
              >
                ☀️ Condição do tempo
              </Text>

              <Text
                style={{
                  fontSize: 20,
                  fontWeight:
                    "bold",
                  color:
                    "#526B45",
                  marginTop: 10,
                  textTransform:
                    "capitalize",
                }}
              >
                {
                  previsaoAmanha.condicao
                }
              </Text>

            </View>

          </View>
        )}

      </ScrollView>

    </View>
  );
}
