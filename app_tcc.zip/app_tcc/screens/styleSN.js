import {
  StyleSheet,
  Platform,
  StatusBar,
} from 'react-native';

const styles = StyleSheet.create({

  safeArea: {
    flex: 1,
    backgroundColor: '#E4EBCF',
    paddingTop:
      Platform.OS === 'android'
        ? StatusBar.currentHeight || 0
        : 0,
  },

  container: {
    flex: 1,
    backgroundColor: '#E4EBCF',
  },

  content: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 35,
  },

  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 22,
  },

  backButton: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: '#E5ECD9',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 13,
  },

  headerTextArea: {
    flex: 1,
    alignItems: 'center',
  },

  headerSpacer: {
    width: 46,
  },

  logoContainer: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,

    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.10,
    shadowRadius: 5,
    elevation: 4,
  },

  logo: {
    width: 70,
    height: 70,
  },

  title: {
    fontSize: 27,
    fontWeight: '800',
    color: '#40552F',
    textAlign: 'center',
  },

  card: {
    backgroundColor: '#FDFDF8',
    borderRadius: 20,
    padding: 17,
    marginBottom: 14,
    flexDirection: 'row',

    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },

  iconCircle: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: '#E8EFD8',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 13,
  },

  icon: {
    fontSize: 19,
  },

  cardContent: {
    flex: 1,
  },

  cardTitle: {
    fontSize: 17,
    fontWeight: '800',
    color: '#405B2B',
    marginBottom: 8,
  },

  text: {
    fontSize: 13,
    lineHeight: 20,
    color: '#68745A',
    marginBottom: 7,
  },

  techList: {
    marginTop: 2,
  },

  techItem: {
    fontSize: 13,
    color: '#68745A',
    lineHeight: 22,
  },

  teamCard: {
    backgroundColor: '#D6E1BB',
    borderRadius: 20,
    padding: 20,
    marginTop: 2,
    alignItems: 'center',

    shadowColor: '#354427',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.06,
    shadowRadius: 5,
    elevation: 2,
  },

  teamTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: '#405B2B',
    marginBottom: 13,
  },

  teamText: {
    fontSize: 13,
    color: '#58664B',
    marginBottom: 6,
    textAlign: 'center',
  },

  school: {
    fontSize: 12,
    color: '#71805D',
    marginTop: 10,
  },

  footer: {
    textAlign: 'center',
    fontSize: 12,
    color: '#71805D',
    marginTop: 22,
    marginBottom: 10,
  },

});
export default styles;