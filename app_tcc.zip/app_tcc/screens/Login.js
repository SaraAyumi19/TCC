import React, {
  useState,
} from "react";

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
} from "react-native";

import {
  useNavigation,
} from "@react-navigation/native";

import { supabase } from "../lib/supabase";

import Style from "../styles/styles";

export default function Login() {
  const navigation =
    useNavigation();

  const [email, setEmail] =
    useState("");

  const [senha, setSenha] =
    useState("");

  const [loading, setLoading] =
    useState(false);

  async function entrar() {
    if (!email || !senha) {
      Alert.alert(
        "Atenção",
        "Preencha todos os campos."
      );

      return;
    }

    setLoading(true);

    const {
      error,
    } =
      await supabase.auth.signInWithPassword({
        email: email.trim(),
        password: senha,
      });

    setLoading(false);

    if (error) {
      Alert.alert(
        "Erro",
        error.message
      );

      return;
    }

    navigation.replace("Page1");
  }

  return (
    <View style={Style.authContainer}>

      <View style={Style.logo}>
        <Text style={Style.logoTexto}>
          Clima
        </Text>

        <Text
          style={Style.logoSubtexto}
        >
          Seu tempo, do seu jeito
        </Text>
      </View>

      <TextInput
        style={Style.authInput}
        placeholder="E-mail"
        placeholderTextColor="#999"
        keyboardType="email-address"
        autoCapitalize="none"
        value={email}
        onChangeText={setEmail}
      />

      <TextInput
        style={Style.authInput}
        placeholder="Senha"
        placeholderTextColor="#999"
        secureTextEntry
        value={senha}
        onChangeText={setSenha}
      />

      <TouchableOpacity
        style={Style.button}
        onPress={entrar}
        disabled={loading}
      >
        <Text style={Style.buttonText}>
          {loading
            ? "Entrando..."
            : "Entrar"}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() =>
          navigation.navigate(
            "Cadastro"
          )
        }
      >
        <Text style={Style.link}>
          Ainda não tenho uma conta
        </Text>
      </TouchableOpacity>

    </View>
  );
}