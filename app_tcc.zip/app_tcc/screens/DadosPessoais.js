import React, {
  useEffect,
  useState,
} from 'react';

import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  StatusBar,
  ActivityIndicator,
  TextInput,
  Image,
  Alert,
  Platform,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

import { supabase } from '../lib/supabase';
import Style from './styleDP';

export default function DadosPessoais() {
  const navigation = useNavigation();

  const [usuario, setUsuario] = useState(null);

  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');

  const [nomeOriginal, setNomeOriginal] =
    useState('');

  const [emailOriginal, setEmailOriginal] =
    useState('');

  const [foto, setFoto] = useState(null);

  const [loading, setLoading] =
    useState(true);

  const [salvando, setSalvando] =
    useState(false);

  useEffect(() => {
    carregarUsuario();
  }, []);

  async function carregarUsuario() {
    try {
      const {
        data: { user },
        error,
      } = await supabase.auth.getUser();

      if (error) {
        throw error;
      }

      if (!user) {
        return;
      }

      setUsuario(user);

      const nomeUsuario =
        user.user_metadata?.name || '';

      const emailUsuario =
        user.email || '';

      const fotoUsuario =
        user.user_metadata?.avatar_url ||
        null;

      setNome(nomeUsuario);
      setEmail(emailUsuario);

      setNomeOriginal(nomeUsuario);
      setEmailOriginal(emailUsuario);

      setFoto(fotoUsuario);
    } catch (error) {
      console.log(error);

      mostrarMensagem(
        'Erro',
        'Não foi possível carregar seus dados.'
      );
    } finally {
      setLoading(false);
    }
  }

  async function salvarAlteracoes() {
    const novoNome = nome.trim();
    const novoEmail = email
      .trim()
      .toLowerCase();

    if (!novoNome) {
      mostrarMensagem(
        'Nome obrigatório',
        'Digite seu nome.'
      );

      return;
    }

    if (!novoEmail) {
      mostrarMensagem(
        'E-mail obrigatório',
        'Digite seu e-mail.'
      );

      return;
    }

    if (
      !novoEmail.includes('@') ||
      !novoEmail.includes('.')
    ) {
      mostrarMensagem(
        'E-mail inválido',
        'Digite um endereço de e-mail válido.'
      );

      return;
    }

    if (
      novoNome === nomeOriginal &&
      novoEmail === emailOriginal
    ) {
      mostrarMensagem(
        'Sem alterações',
        'Nenhum dado foi modificado.'
      );

      return;
    }

    try {
      setSalvando(true);

      if (novoNome !== nomeOriginal) {
        const {
          error: nomeError,
        } = await supabase.auth.updateUser({
          data: {
            name: novoNome,
          },
        });

        if (nomeError) {
          throw nomeError;
        }
      }

      let emailAlterado = false;

      if (novoEmail !== emailOriginal) {
        const {
          error: emailError,
        } = await supabase.auth.updateUser({
          email: novoEmail,
        });

        if (emailError) {
          throw emailError;
        }

        emailAlterado = true;
      }

      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser();

      if (userError) {
        throw userError;
      }

      if (user) {
        setUsuario(user);

        const nomeAtualizado =
          user.user_metadata?.name ||
          novoNome;

        const emailAtualizado =
          user.email ||
          emailOriginal;

        setNome(nomeAtualizado);
        setNomeOriginal(nomeAtualizado);

        if (!emailAlterado) {
          setEmail(emailAtualizado);
          setEmailOriginal(
            emailAtualizado
          );
        }
      }

      if (emailAlterado) {
        mostrarMensagem(
          'Alteração solicitada',
          'Seu nome foi atualizado. Para alterar o e-mail, verifique a mensagem enviada pelo Supabase para confirmar o novo endereço.'
        );

        setEmail(novoEmail);
      } else {
        mostrarMensagem(
          'Dados atualizados',
          'Suas informações foram salvas com sucesso.'
        );
      }
    } catch (error) {
      console.log(error);

      mostrarMensagem(
        'Erro',
        error?.message ||
          'Não foi possível salvar as alterações.'
      );
    } finally {
      setSalvando(false);
    }
  }

  function mostrarMensagem(
    titulo,
    mensagem
  ) {
    if (Platform.OS === 'web') {
      alert(
        `${titulo}\n\n${mensagem}`
      );

      return;
    }

    Alert.alert(
      titulo,
      mensagem
    );
  }

  function formatarData(data) {
    if (!data) {
      return 'Não disponível';
    }

    return new Date(
      data
    ).toLocaleDateString(
      'pt-BR',
      {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
      }
    );
  }

  const dataCadastro =
    formatarData(
      usuario?.created_at
    );

  const emailConfirmado =
    usuario?.email_confirmed_at
      ? 'Confirmado'
      : 'Não confirmado';

  const houveAlteracao =
    nome.trim() !== nomeOriginal ||
    email.trim().toLowerCase() !==
      emailOriginal.toLowerCase();

  return (
    <SafeAreaView
      style={Style.safeArea}
    >
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#F4F6EE"
        translucent={false}
      />

      <ScrollView
        style={Style.scroll}
        contentContainerStyle={
          Style.scrollContent
        }
        showsVerticalScrollIndicator={
          true
        }
        keyboardShouldPersistTaps="handled"
      >
        <View style={Style.header}>
          <TouchableOpacity
            style={Style.backButton}
            onPress={() =>
              navigation.goBack()
            }
            activeOpacity={0.8}
          >
            <Ionicons
              name="arrow-back"
              size={25}
              color="#40552F"
            />
          </TouchableOpacity>

          <Text
            style={Style.headerTitle}
          >
            Dados pessoais
          </Text>

          <View
            style={Style.headerSpacer}
          />
        </View>

        {loading ? (
          <ActivityIndicator
            size="large"
            color="#536B38"
            style={Style.loading}
          />
        ) : (
          <>
            <View
              style={Style.photoCard}
            >
              {foto ? (
                <>
                  <Image
                    source={{
                      uri: foto,
                    }}
                    style={
                      Style.profilePhoto
                    }
                    resizeMode="cover"
                  />

                  <View
                    style={
                      Style.photoOverlay
                    }
                  />

                  <View
                    style={
                      Style.photoTextArea
                    }
                  >
                    <Text
                      style={
                        Style.photoName
                      }
                    >
                      {nomeOriginal ||
                        'AgroControl'}
                    </Text>

                    <Text
                      style={
                        Style.photoEmail
                      }
                    >
                      {emailOriginal}
                    </Text>
                  </View>
                </>
              ) : (
                <View
                  style={
                    Style.noPhotoArea
                  }
                >
                  <Ionicons
                    name="person-outline"
                    size={65}
                    color="#536B38"
                  />

                  <Text
                    style={
                      Style.noPhotoText
                    }
                  >
                    Foto de perfil
                  </Text>
                </View>
              )}
            </View>

            <View
              style={
                Style.sectionHeader
              }
            >
              <View>
                <Text
                  style={
                    Style.sectionTitle
                  }
                >
                  Seus dados
                </Text>

                <Text
                  style={
                    Style.sectionSubtitle
                  }
                >
                  Altere suas informações abaixo
                </Text>
              </View>

              <Ionicons
                name="create-outline"
                size={24}
                color="#536B38"
              />
            </View>

            <View
              style={Style.card}
            >
              <View
                style={Style.iconArea}
              >
                <Ionicons
                  name="person-outline"
                  size={23}
                  color="#536B38"
                />
              </View>

              <View
                style={Style.textArea}
              >
                <Text
                  style={Style.label}
                >
                  Nome
                </Text>

                <TextInput
                  style={Style.input}
                  value={nome}
                  onChangeText={setNome}
                  placeholder="Digite seu nome"
                  placeholderTextColor="#9AA391"
                  autoCapitalize="words"
                  editable={!salvando}
                />
              </View>
            </View>

            <View
              style={Style.card}
            >
              <View
                style={Style.iconArea}
              >
                <Ionicons
                  name="mail-outline"
                  size={23}
                  color="#536B38"
                />
              </View>

              <View
                style={Style.textArea}
              >
                <Text
                  style={Style.label}
                >
                  E-mail
                </Text>

                <TextInput
                  style={Style.input}
                  value={email}
                  onChangeText={setEmail}
                  placeholder="Digite seu e-mail"
                  placeholderTextColor="#9AA391"
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                  editable={!salvando}
                />
              </View>
            </View>

            <View
              style={
                Style.readOnlyCard
              }
            >
              <View
                style={Style.iconArea}
              >
                <Ionicons
                  name={
                    usuario?.email_confirmed_at
                      ? 'checkmark-circle-outline'
                      : 'alert-circle-outline'
                  }
                  size={23}
                  color="#536B38"
                />
              </View>

              <View
                style={Style.textArea}
              >
                <Text
                  style={Style.label}
                >
                  Situação do e-mail
                </Text>

                <Text
                  style={
                    Style.readOnlyValue
                  }
                >
                  {emailConfirmado}
                </Text>
              </View>

              <Ionicons
                name="lock-closed-outline"
                size={17}
                color="#A1AA98"
              />
            </View>

            <View
              style={
                Style.readOnlyCard
              }
            >
              <View
                style={Style.iconArea}
              >
                <Ionicons
                  name="calendar-outline"
                  size={23}
                  color="#536B38"
                />
              </View>

              <View
                style={Style.textArea}
              >
                <Text
                  style={Style.label}
                >
                  Conta criada em
                </Text>

                <Text
                  style={
                    Style.readOnlyValue
                  }
                >
                  {dataCadastro}
                </Text>
              </View>

              <Ionicons
                name="lock-closed-outline"
                size={17}
                color="#A1AA98"
              />
            </View>

            <TouchableOpacity
              style={[
                Style.saveButton,
                (!houveAlteracao ||
                  salvando) &&
                  Style.saveButtonDisabled,
              ]}
              onPress={
                salvarAlteracoes
              }
              disabled={
                !houveAlteracao ||
                salvando
              }
              activeOpacity={0.85}
            >
              {salvando ? (
                <ActivityIndicator
                  size="small"
                  color="#FFFFFF"
                />
              ) : (
                <>
                  <Ionicons
                    name="save-outline"
                    size={22}
                    color="#FFFFFF"
                  />

                  <Text
                    style={
                      Style.saveButtonText
                    }
                  >
                    Salvar alterações
                  </Text>
                </>
              )}
            </TouchableOpacity>

          </>
        )}

        <Text style={Style.footer}>
          Simples • Prático • Sustentável
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}