import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';

import { useNavigation } from '@react-navigation/native';

import { supabase } from '../../lib/supabase';

import Style from './style';

export default function Login() {
  const navigation = useNavigation();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  async function handleSignIn() {
    const emailLimpo = email.trim();

    setErrorMessage('');

    if (!emailLimpo || !password) {
      setErrorMessage('Preencha o e-mail e a senha.');
      return;
    }

    if (!emailLimpo.includes('@')) {
      setErrorMessage(
        'Digite um endereço de e-mail válido.'
      );
      return;
    }

    try {
      setLoading(true);

      const { data, error } =
        await supabase.auth.signInWithPassword({
          email: emailLimpo,
          password,
        });

      console.log('LOGIN DATA:', data);
      console.log('LOGIN ERROR:', error);

      if (error) {
        const mensagem =
          error.message?.toLowerCase() || '';

        if (
          mensagem.includes(
            'invalid login credentials'
          ) ||
          mensagem.includes(
            'invalid credentials'
          )
        ) {
          setErrorMessage(
            'E-mail ou senha incorretos.'
          );
        } else if (
          mensagem.includes(
            'email not confirmed'
          )
        ) {
          setErrorMessage(
            'Seu e-mail ainda não foi confirmado.'
          );
        } else {
          setErrorMessage(
            'Não foi possível entrar. Verifique seus dados.'
          );
        }

        return;
      }

      if (!data?.session) {
        setErrorMessage(
          'Não foi possível iniciar sua sessão.'
        );
        return;
      }

      /*
        Não fazemos navigation.navigate('Page1').

        O RootNavigator detecta automaticamente
        a sessão criada pelo Supabase e abre
        o AppNavigator.
      */
    } catch (error) {
      console.log('ERRO NO LOGIN:', error);

      setErrorMessage(
        'Não foi possível conectar. Tente novamente.'
      );
    } finally {
      setLoading(false);
    }
  }

  function handleEmailChange(text) {
    setEmail(text);

    if (errorMessage) {
      setErrorMessage('');
    }
  }

  function handlePasswordChange(text) {
    setPassword(text);

    if (errorMessage) {
      setErrorMessage('');
    }
  }

  return (
    <KeyboardAvoidingView
      style={Style.keyboard}
      behavior={
        Platform.OS === 'ios'
          ? 'padding'
          : undefined
      }
    >
      <ScrollView
        style={Style.scroll}
        contentContainerStyle={
          Style.scrollContainer
        }
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={true}
        nestedScrollEnabled={true}
      >
        <View style={Style.container}>

          <View style={Style.topDecoration} />

          <View style={Style.logoArea}>
            <View style={Style.logoCircle}>
              <Image
                source={require(
                  '../../assets/icon.png'
                )}
                style={Style.logo}
                resizeMode="contain"
              />
            </View>

            <Text style={Style.appName}>
              AgroControl
            </Text>

            <Text style={Style.slogan}>
              A melhor tecnologia para cuidar da
              sua plantação.
            </Text>
          </View>

          <View style={Style.card}>
            <Text style={Style.label}>
              E-mail
            </Text>

            <TextInput
              style={Style.input}
              placeholder="Digite seu e-mail"
              placeholderTextColor="#929B87"
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
              value={email}
              onChangeText={handleEmailChange}
              editable={!loading}
              returnKeyType="next"
            />

            <Text style={Style.label}>
              Senha
            </Text>

            <TextInput
              style={Style.input}
              placeholder="Digite sua senha"
              placeholderTextColor="#929B87"
              secureTextEntry
              autoCapitalize="none"
              autoCorrect={false}
              value={password}
              onChangeText={
                handlePasswordChange
              }
              editable={!loading}
              returnKeyType="done"
              onSubmitEditing={
                handleSignIn
              }
            />

            {errorMessage ? (
              <View
                style={Style.errorContainer}
              >
                <Text
                  style={Style.errorText}
                >
                  {errorMessage}
                </Text>
              </View>
            ) : null}

            <TouchableOpacity
              style={[
                Style.button,
                loading &&
                  Style.buttonDisabled,
              ]}
              onPress={handleSignIn}
              disabled={loading}
              activeOpacity={0.85}
            >
              {loading ? (
                <View
                  style={Style.loadingArea}
                >
                  <ActivityIndicator
                    color="#FFFFFF"
                    size="small"
                  />

                  <Text
                    style={Style.buttonText}
                  >
                    Entrando...
                  </Text>
                </View>
              ) : (
                <Text
                  style={Style.buttonText}
                >
                  Entrar
                </Text>
              )}
            </TouchableOpacity>

            <View
              style={Style.registerArea}
            >
              <Text
                style={
                  Style.registerQuestion
                }
              >
                Ainda não tem uma conta?
              </Text>

              <TouchableOpacity
                onPress={() =>
                  navigation.navigate(
                    'Cadastro'
                  )
                }
                disabled={loading}
              >
                <Text
                  style={
                    Style.registerLink
                  }
                >
                  Criar conta
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          <Text style={Style.footer}>
            Simples • Prático • Sustentável
          </Text>

        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}