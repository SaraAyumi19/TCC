import { StyleSheet } from 'react-native';

const Style = StyleSheet.create({
  keyboard: {
    flex: 1,
    backgroundColor: '#D9E2C3',
  },

  scroll: {
    flex: 1,
    backgroundColor: '#D9E2C3',
  },

  scrollContainer: {
    flexGrow: 1,
    paddingBottom: 40,
  },

  container: {
    width: '100%',
    minHeight: '100%',

    backgroundColor: '#D9E2C3',

    paddingHorizontal: 24,
    paddingTop: 55,
    paddingBottom: 40,

    position: 'relative',
  },

  topDecoration: {
    position: 'absolute',

    width: 330,
    height: 330,
    borderRadius: 165,

    backgroundColor: '#607545',

    top: -190,
    right: -120,

    opacity: 0.55,
  },

  logoArea: {
    width: '100%',
    alignItems: 'center',
    marginBottom: 30,
  },

  logoCircle: {
    width: 120,
    height: 120,

    borderRadius: 60,

    backgroundColor: '#F7F8F1',

    alignItems: 'center',
    justifyContent: 'center',

    marginBottom: 16,

    shadowColor: '#344123',

    shadowOffset: {
      width: 0,
      height: 5,
    },

    shadowOpacity: 0.15,
    shadowRadius: 8,

    elevation: 6,
  },

  logo: {
    width: 88,
    height: 88,
  },

  appName: {
    fontSize: 31,
    fontWeight: '800',

    color: '#40552F',

    letterSpacing: 0.3,
  },

  slogan: {
    fontSize: 14,
    lineHeight: 20,

    color: '#5E6F50',

    textAlign: 'center',

    maxWidth: 290,

    marginTop: 7,
  },

  card: {
    width: '100%',

    backgroundColor: '#F8F9F3',

    borderRadius: 26,

    paddingHorizontal: 22,
    paddingVertical: 28,

    shadowColor: '#344123',

    shadowOffset: {
      width: 0,
      height: 8,
    },

    shadowOpacity: 0.14,
    shadowRadius: 12,

    elevation: 8,
  },

  label: {
    fontSize: 14,
    fontWeight: '600',

    color: '#4B5F3B',

    marginBottom: 7,
    marginLeft: 2,
  },

  input: {
    width: '100%',
    height: 54,

    backgroundColor: '#FFFFFF',

    borderRadius: 15,

    borderWidth: 1,
    borderColor: '#D5DDC8',

    paddingHorizontal: 16,

    fontSize: 15,
    color: '#334229',

    marginBottom: 17,
  },

  errorContainer: {
    width: '100%',

    backgroundColor: '#FDECE8',

    borderWidth: 1,
    borderColor: '#D99A8C',

    borderRadius: 12,

    paddingVertical: 10,
    paddingHorizontal: 13,

    marginTop: -4,
    marginBottom: 14,
  },

  errorText: {
    color: '#8A3E32',

    fontSize: 13,
    fontWeight: '600',

    textAlign: 'center',

    lineHeight: 18,
  },

  button: {
    width: '100%',
    height: 56,

    borderRadius: 16,

    backgroundColor: '#536B38',

    alignItems: 'center',
    justifyContent: 'center',

    marginTop: 7,

    shadowColor: '#40542C',

    shadowOffset: {
      width: 0,
      height: 4,
    },

    shadowOpacity: 0.18,
    shadowRadius: 5,

    elevation: 4,
  },

  buttonDisabled: {
    opacity: 0.65,
  },

  buttonText: {
    color: '#FFFFFF',

    fontSize: 17,
    fontWeight: '700',
  },

  loadingArea: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },

  registerArea: {
    width: '100%',

    alignItems: 'center',
    justifyContent: 'center',

    marginTop: 23,
  },

  registerQuestion: {
    fontSize: 14,

    color: '#737E69',

    marginBottom: 5,
  },

  registerLink: {
    fontSize: 15,

    color: '#536B38',

    fontWeight: '800',
  },

  footer: {
    color: '#667558',

    textAlign: 'center',

    fontSize: 12,

    marginTop: 22,
    marginBottom: 20,

    letterSpacing: 0.4,
  },
});

export default Style;
