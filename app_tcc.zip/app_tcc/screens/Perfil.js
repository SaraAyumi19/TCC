import React, { useEffect, useState } from "react";

import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  Image,
  Alert,
  ActivityIndicator,
  ScrollView,
} from "react-native";

import * as ImagePicker from "expo-image-picker";

import { Ionicons } from "@expo/vector-icons";

import { useNavigation } from "@react-navigation/native";

import { supabase } from "../lib/supabase";

export default function Perfil() {
  const navigation = useNavigation();

  const [user, setUser] = useState(null);

  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");

  const [foto, setFoto] = useState(null);

  const [editando, setEditando] = useState(false);

  const [loading, setLoading] = useState(false);

  // =====================================================
  // CARREGAR USUÁRIO
  // =====================================================

  useEffect(() => {
    carregarUsuario();
  }, []);

  async function carregarUsuario() {
    try {
      const {
        data: { user },
        error,
      } = await supabase.auth.getUser();

      if (error) {
        console.log("ERRO USER:", error);
        return;
      }

      if (!user) {
        console.log("Nenhum usuário logado");
        return;
      }

      console.log("USUÁRIO:", user.id);

      setUser(user);

      setNome(
        user.user_metadata?.name || ""
      );

      setEmail(
        user.email || ""
      );

      setFoto(
        user.user_metadata?.avatar_url || null
      );

    } catch (error) {
      console.log(
        "ERRO AO CARREGAR:",
        error
      );
    }
  }

  // =====================================================
  // ESCOLHER FOTO
  // =====================================================

  async function escolherFoto() {
    try {
      // Solicita permissão
      const permission =
        await ImagePicker.requestMediaLibraryPermissionsAsync();

      if (!permission.granted) {
        Alert.alert(
          "Permissão necessária",
          "Permita o acesso às suas fotos para escolher uma imagem."
        );

        return;
      }

      // Abre a galeria
      const resultado =
        await ImagePicker.launchImageLibraryAsync({
          mediaTypes: ["images"],
          allowsEditing: true,
          aspect: [1, 1],
          quality: 0.8,
        });

      // Usuário cancelou
      if (resultado.canceled) {
        return;
      }

      const imagem =
        resultado.assets[0];

      if (!imagem || !imagem.uri) {
        Alert.alert(
          "Erro",
          "Não foi possível obter a imagem."
        );

        return;
      }

      console.log(
        "IMAGEM SELECIONADA:",
        imagem.uri
      );

      // Mostra a imagem imediatamente
      setFoto(imagem.uri);

      // Faz upload
      await uploadFoto(imagem.uri);

    } catch (error) {
      console.log(
        "ERRO AO ESCOLHER FOTO:",
        error
      );

      Alert.alert(
        "Erro",
        "Não foi possível escolher a foto."
      );
    }
  }

  // =====================================================
  // UPLOAD
  // =====================================================

  async function uploadFoto(uri) {
    if (!user) {
      Alert.alert(
        "Erro",
        "Usuário não encontrado."
      );

      return;
    }

    setLoading(true);

    try {
      console.log(
        "Iniciando upload..."
      );

      // =================================================
      // TRANSFORMA URI EM BLOB
      // =================================================

      const response =
        await fetch(uri);

      const blob =
        await response.blob();

      console.log(
        "Blob criado:",
        blob.type,
        blob.size
      );

      // =================================================
      // CAMINHO DO ARQUIVO
      // =================================================

      const caminho =
        `${user.id}/avatar.jpg`;

      console.log(
        "Caminho:",
        caminho
      );

      // =================================================
      // UPLOAD PARA O BUCKET
      // =================================================

      const {
        data,
        error,
      } = await supabase.storage
        .from("images")
        .upload(
          caminho,
          blob,
          {
            contentType:
              "image/jpeg",

            upsert: true,
          }
        );

      if (error) {
        console.log(
          "ERRO DO SUPABASE:",
          error
        );

        throw error;
      }

      console.log(
        "UPLOAD OK:",
        data
      );

      // =================================================
      // PEGAR URL PÚBLICA
      // =================================================

      const {
        data: publicData,
      } = supabase.storage
        .from("images")
        .getPublicUrl(caminho);

      const url =
        publicData.publicUrl;

      console.log(
        "URL:",
        url
      );

      // =================================================
      // SALVAR URL NO USUÁRIO
      // =================================================

      const {
        error: updateError,
      } = await supabase.auth.updateUser({
        data: {
          avatar_url: url,
        },
      });

      if (updateError) {
        console.log(
          "ERRO AO SALVAR URL:",
          updateError
        );

        throw updateError;
      }

      // =================================================
      // ATUALIZA A FOTO
      // =================================================

      setFoto(url);

      Alert.alert(
        "Sucesso!",
        "Sua foto foi atualizada."
      );

      console.log(
        "FOTO SALVA COM SUCESSO"
      );

    } catch (error) {
      console.log(
        "ERRO NO UPLOAD:",
        error
      );

      Alert.alert(
        "Erro no upload",
        error?.message ||
          "Não foi possível salvar a foto."
      );

      // Recarrega a foto antiga
      carregarUsuario();

    } finally {
      setLoading(false);
    }
  }

  // =====================================================
  // SALVAR NOME
  // =====================================================

  async function salvarPerfil() {
    if (!nome.trim()) {
      Alert.alert(
        "Atenção",
        "Digite seu nome."
      );

      return;
    }

    setLoading(true);

    try {
      const {
        error,
      } = await supabase.auth.updateUser({
        data: {
          name: nome.trim(),
          avatar_url: foto,
        },
      });

      if (error) {
        throw error;
      }

      setEditando(false);

      Alert.alert(
        "Sucesso",
        "Perfil atualizado."
      );

    } catch (error) {
      console.log(
        "ERRO PERFIL:",
        error
      );

      Alert.alert(
        "Erro",
        "Não foi possível atualizar o perfil."
      );

    } finally {
      setLoading(false);
    }
  }

  // =====================================================
  // SAIR
  // =====================================================

  async function sair() {
    await supabase.auth.signOut();

    navigation.reset({
      index: 0,
      routes: [
        {
          name: "Login",
        },
      ],
    });
  }

  // =====================================================
  // TELA
  // =====================================================

  return (
    <ScrollView
      style={{
        flex: 1,
        backgroundColor: "#F3E8D7",
      }}
      contentContainerStyle={{
        alignItems: "center",
        paddingBottom: 50,
      }}
    >

      {/* VOLTAR */}

      <View
        style={{
          width: "90%",
          marginTop: 50,
        }}
      >
        <TouchableOpacity
          onPress={() =>
            navigation.goBack()
          }
        >
          <Ionicons
            name="arrow-back"
            size={30}
            color="#405438"
          />
        </TouchableOpacity>
      </View>

      {/* TÍTULO */}

      <Text
        style={{
          fontSize: 30,
          fontWeight: "bold",
          color: "#3D3026",
          marginTop: 15,
        }}
      >
        Meu perfil
      </Text>

      {/* FOTO */}

      <View
        style={{
          marginTop: 30,
          alignItems: "center",
        }}
      >

        <View
          style={{
            width: 140,
            height: 140,
            borderRadius: 70,
            backgroundColor: "#DDD2C2",
            borderWidth: 4,
            borderColor: "#526B45",
            overflow: "hidden",
            justifyContent: "center",
            alignItems: "center",
          }}
        >

          {foto ? (
            <Image
              source={{
                uri: foto,
              }}
              style={{
                width: "100%",
                height: "100%",
              }}
            />
          ) : (
            <Ionicons
              name="person"
              size={70}
              color="#526B45"
            />
          )}

        </View>

        {/* BOTÃO CÂMERA */}

        <TouchableOpacity
          onPress={escolherFoto}
          disabled={loading}
          style={{
            position: "absolute",
            bottom: 0,
            right: 0,
            width: 45,
            height: 45,
            borderRadius: 23,
            backgroundColor: "#526B45",
            justifyContent: "center",
            alignItems: "center",
            borderWidth: 3,
            borderColor: "#F3E8D7",
          }}
        >

          {loading ? (
            <ActivityIndicator
              color="white"
            />
          ) : (
            <Ionicons
              name="camera"
              size={22}
              color="white"
            />
          )}

        </TouchableOpacity>

      </View>

      {/* INFORMAÇÕES */}

      <View
        style={{
          width: "90%",
          backgroundColor: "white",
          marginTop: 35,
          padding: 20,
          borderRadius: 20,
        }}
      >

        <Text
          style={{
            color: "#766657",
            marginBottom: 8,
          }}
        >
          Nome
        </Text>

        {editando ? (
          <TextInput
            value={nome}
            onChangeText={setNome}
            placeholder="Seu nome"
            style={{
              borderWidth: 1,
              borderColor: "#D5C8B8",
              borderRadius: 12,
              padding: 12,
              marginBottom: 20,
              color: "#3D3026",
            }}
          />
        ) : (
          <Text
            style={{
              fontSize: 18,
              fontWeight: "bold",
              color: "#3D3026",
              marginBottom: 20,
            }}
          >
            {nome || "Não informado"}
          </Text>
        )}

        <Text
          style={{
            color: "#766657",
            marginBottom: 8,
          }}
        >
          E-mail
        </Text>

        <Text
          style={{
            fontSize: 17,
            color: "#3D3026",
          }}
        >
          {email}
        </Text>

      </View>

      {/* EDITAR / SALVAR */}

      {editando ? (

        <TouchableOpacity
          onPress={salvarPerfil}
          disabled={loading}
          style={{
            width: "90%",
            backgroundColor: "#526B45",
            padding: 17,
            borderRadius: 15,
            alignItems: "center",
            marginTop: 20,
          }}
        >

          {loading ? (
            <ActivityIndicator
              color="white"
            />
          ) : (
            <Text
              style={{
                color: "white",
                fontWeight: "bold",
                fontSize: 16,
              }}
            >
              Salvar alterações
            </Text>
          )}

        </TouchableOpacity>

      ) : (

        <TouchableOpacity
          onPress={() =>
            setEditando(true)
          }
          style={{
            width: "90%",
            backgroundColor: "#8B5E3C",
            padding: 17,
            borderRadius: 15,
            alignItems: "center",
            marginTop: 20,
          }}
        >
          <Text
            style={{
              color: "white",
              fontWeight: "bold",
              fontSize: 16,
            }}
          >
            Editar perfil
          </Text>
        </TouchableOpacity>

      )}

      {/* SAIR */}

      <TouchableOpacity
        onPress={sair}
        style={{
          marginTop: 25,
          padding: 15,
        }}
      >
        <Text
          style={{
            color: "#A94442",
            fontWeight: "bold",
          }}
        >
          Sair da conta
        </Text>
      </TouchableOpacity>

    </ScrollView>
  );
}
