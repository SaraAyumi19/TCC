import React, {
  useEffect,
  useState,
} from 'react';

import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  StatusBar,
  ActivityIndicator,
  Image,
  Alert,
  Platform,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import * as ImagePicker from 'expo-image-picker';
import AsyncStorage from '@react-native-async-storage/async-storage';

import { supabase } from '../lib/supabase';
import Style from './stylePerfil';

export default function Perfil() {
  const navigation = useNavigation();

  const [usuario, setUsuario] = useState(null);
  const [imagem, setImagem] = useState(null);
  const [loading, setLoading] = useState(true);
  const [salvandoFoto, setSalvandoFoto] = useState(false);

  useEffect(() => {
    carregarUsuario();
  }, []);

  async function carregarUsuario() {
    try {
      const {
        data: { user },
        error,
      } = await supabase.auth.getUser();

      if (error) {
        throw error;
      }

      if (!user) {
        return;
      }

      setUsuario(user);

      const fotoSupabase =
        user.user_metadata?.avatar_url || null;

      if (fotoSupabase) {
        setImagem(fotoSupabase);

        await AsyncStorage.setItem(
          `fotoPerfil_${user.id}`,
          fotoSupabase
        );
      } else {
        const imagemSalva =
          await AsyncStorage.getItem(
            `fotoPerfil_${user.id}`
          );

        if (imagemSalva) {
          setImagem(imagemSalva);
        }
      }
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  }

  async function pegarImagem() {
    try {
      if (!usuario?.id) {
        mostrarMensagem(
          'Erro',
          'Não foi possível identificar o usuário.'
        );

        return;
      }

      const permissao =
        await ImagePicker.requestMediaLibraryPermissionsAsync();

      if (!permissao.granted) {
        mostrarMensagem(
          'Permissão necessária',
          'Permita o acesso à galeria para escolher sua foto de perfil.'
        );

        return;
      }

      const resultado =
        await ImagePicker.launchImageLibraryAsync({
          mediaTypes: ['images'],
          allowsEditing: true,
          aspect: [1, 1],
          quality: 0.8,
        });

      if (
        resultado.canceled ||
        !resultado.assets?.length
      ) {
        return;
      }

      const asset = resultado.assets[0];

      await salvarFoto(
        asset.uri,
        asset.mimeType
      );
    } catch (error) {
      console.log(error);

      mostrarMensagem(
        'Erro',
        'Não foi possível selecionar a foto.'
      );
    }
  }

  async function salvarFoto(uri, mimeType) {
    try {
      setSalvandoFoto(true);

      const resposta = await fetch(uri);
      const arrayBuffer =
        await resposta.arrayBuffer();

      const caminho =
        `${usuario.id}/avatar`;

      const {
        error: uploadError,
      } = await supabase.storage
        .from('images')
        .upload(
          caminho,
          arrayBuffer,
          {
            contentType:
              mimeType || 'image/jpeg',
            upsert: true,
          }
        );

      if (uploadError) {
        throw uploadError;
      }

      const {
        data: publicUrlData,
      } = supabase.storage
        .from('images')
        .getPublicUrl(caminho);

      if (!publicUrlData?.publicUrl) {
        throw new Error(
          'Não foi possível gerar a URL da foto.'
        );
      }

      const fotoUrl =
        `${publicUrlData.publicUrl}?v=${Date.now()}`;

      const {
        data,
        error: updateError,
      } = await supabase.auth.updateUser({
        data: {
          avatar_url: fotoUrl,
        },
      });

      if (updateError) {
        throw updateError;
      }

      setUsuario(data.user);
      setImagem(fotoUrl);

      await AsyncStorage.setItem(
        `fotoPerfil_${usuario.id}`,
        fotoUrl
      );

      mostrarMensagem(
        'Foto atualizada',
        'Sua foto de perfil foi salva.'
      );
    } catch (error) {
      console.log(error);

      mostrarMensagem(
        'Erro',
        error?.message ||
          'Não foi possível salvar a foto de perfil.'
      );
    } finally {
      setSalvandoFoto(false);
    }
  }

  async function removerImagem() {
    try {
      if (!usuario?.id) {
        return;
      }

      setSalvandoFoto(true);

      const caminho =
        `${usuario.id}/avatar`;

      const {
        error: storageError,
      } = await supabase.storage
        .from('images')
        .remove([caminho]);

      if (
        storageError &&
        !storageError.message
          ?.toLowerCase()
          .includes('not found')
      ) {
        console.log(storageError);
      }

      const {
        data,
        error: updateError,
      } = await supabase.auth.updateUser({
        data: {
          avatar_url: null,
        },
      });

      if (updateError) {
        throw updateError;
      }

      await AsyncStorage.removeItem(
        `fotoPerfil_${usuario.id}`
      );

      setUsuario(data.user);
      setImagem(null);

      mostrarMensagem(
        'Foto removida',
        'Sua foto de perfil foi removida.'
      );
    } catch (error) {
      console.log(error);

      mostrarMensagem(
        'Erro',
        'Não foi possível remover a foto.'
      );
    } finally {
      setSalvandoFoto(false);
    }
  }

  function abrirOpcoesFoto() {
    if (salvandoFoto) {
      return;
    }

    if (!imagem) {
      pegarImagem();
      return;
    }

    if (Platform.OS === 'web') {
      pegarImagem();
      return;
    }

    Alert.alert(
      'Foto de perfil',
      'O que deseja fazer?',
      [
        {
          text: 'Escolher outra foto',
          onPress: pegarImagem,
        },
        {
          text: 'Remover foto',
          style: 'destructive',
          onPress: removerImagem,
        },
        {
          text: 'Cancelar',
          style: 'cancel',
        },
      ]
    );
  }

  function mostrarMensagem(
    titulo,
    mensagem
  ) {
    if (Platform.OS === 'web') {
      alert(`${titulo}\n\n${mensagem}`);
      return;
    }

    Alert.alert(
      titulo,
      mensagem
    );
  }

  async function sair() {
    try {
      const {
        error,
      } = await supabase.auth.signOut();

      if (error) {
        throw error;
      }
    } catch (error) {
      console.log(error);

      mostrarMensagem(
        'Erro',
        'Não foi possível sair da conta.'
      );
    }
  }

  const nome =
    usuario?.user_metadata?.name ||
    'Usuário';

  const email =
    usuario?.email ||
    'E-mail não disponível';

  return (
    <SafeAreaView style={Style.safeArea}>
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#F4F6EE"
        translucent={false}
      />

      <ScrollView
        style={Style.scroll}
        contentContainerStyle={
          Style.scrollContent
        }
        showsVerticalScrollIndicator={true}
      >
        <View style={Style.header}>
          <TouchableOpacity
            style={Style.backButton}
            onPress={() =>
              navigation.goBack()
            }
            activeOpacity={0.8}
          >
            <Ionicons
              name="arrow-back"
              size={25}
              color="#40552F"
            />
          </TouchableOpacity>

          <Text style={Style.headerTitle}>
            Meu perfil
          </Text>

          <View
            style={Style.headerSpacer}
          />
        </View>

        {loading ? (
          <ActivityIndicator
            size="large"
            color="#536B38"
            style={Style.loading}
          />
        ) : (
          <>
            <View
              style={Style.profileCard}
            >
              <View
                style={Style.profileTop}
              >
                <View
                  style={Style.photoArea}
                >
                  <TouchableOpacity
                    style={
                      Style.avatarButton
                    }
                    onPress={
                      abrirOpcoesFoto
                    }
                    activeOpacity={0.85}
                    disabled={salvandoFoto}
                  >
                    {imagem ? (
                      <Image
                        source={{
                          uri: imagem,
                        }}
                        style={
                          Style.avatarImage
                        }
                      />
                    ) : (
                      <View
                        style={
                          Style.avatarPlaceholder
                        }
                      >
                        <Ionicons
                          name="person-outline"
                          size={55}
                          color="#536B38"
                        />
                      </View>
                    )}

                    <View
                      style={
                        Style.cameraButton
                      }
                    >
                      {salvandoFoto ? (
                        <ActivityIndicator
                          size="small"
                          color="#FFFFFF"
                        />
                      ) : (
                        <Ionicons
                          name="camera"
                          size={18}
                          color="#FFFFFF"
                        />
                      )}
                    </View>
                  </TouchableOpacity>
                </View>

                <Text style={Style.name}>
                  {nome}
                </Text>

                <Text style={Style.email}>
                  {email}
                </Text>

                <TouchableOpacity
                  style={
                    Style.changePhotoButton
                  }
                  onPress={
                    abrirOpcoesFoto
                  }
                  activeOpacity={0.8}
                  disabled={salvandoFoto}
                >
                  {salvandoFoto ? (
                    <ActivityIndicator
                      size="small"
                      color="#536B38"
                    />
                  ) : (
                    <>
                      <Ionicons
                        name="image-outline"
                        size={18}
                        color="#536B38"
                      />

                      <Text
                        style={
                          Style.changePhotoText
                        }
                      >
                        {imagem
                          ? 'Alterar foto'
                          : 'Adicionar foto'}
                      </Text>
                    </>
                  )}
                </TouchableOpacity>
              </View>
            </View>

            <Text
              style={
                Style.welcomeDescription
              }
            />

            <View
              style={Style.menuArea}
            >
              <TouchableOpacity
                style={Style.menuItem}
                activeOpacity={0.8}
                onPress={() =>
                  navigation.navigate(
                    'DadosPessoais'
                  )
                }
              >
                <View
                  style={[
                    Style.menuIcon,
                    Style.menuIconGreen,
                  ]}
                >
                  <Ionicons
                    name="person-outline"
                    size={22}
                    color="#536B38"
                  />
                </View>

                <View
                  style={
                    Style.menuTextArea
                  }
                >
                  <Text
                    style={
                      Style.menuTitle
                    }
                  >
                    Dados pessoais
                  </Text>

                  <Text
                    style={
                      Style.menuSubtitle
                    }
                  >
                    Veja as informações da sua conta
                  </Text>
                </View>

                <Ionicons
                  name="chevron-forward"
                  size={21}
                  color="#8B9583"
                />
              </TouchableOpacity>

              <View
                style={
                  Style.accountInfo
                }
              >
                <View
                  style={
                    Style.accountRow
                  }
                >
                  <View
                    style={
                      Style.accountIcon
                    }
                  >
                    <Ionicons
                      name="person-outline"
                      size={20}
                      color="#536B38"
                    />
                  </View>

                  <View
                    style={
                      Style.accountTextArea
                    }
                  >
                    <Text
                      style={
                        Style.accountLabel
                      }
                    >
                      Nome
                    </Text>

                    <Text
                      style={
                        Style.accountValue
                      }
                    >
                      {nome}
                    </Text>
                  </View>
                </View>

                <View
                  style={
                    Style.accountDivider
                  }
                />

                <View
                  style={
                    Style.accountRow
                  }
                >
                  <View
                    style={
                      Style.accountIcon
                    }
                  >
                    <Ionicons
                      name="mail-outline"
                      size={20}
                      color="#536B38"
                    />
                  </View>

                  <View
                    style={
                      Style.accountTextArea
                    }
                  >
                    <Text
                      style={
                        Style.accountLabel
                      }
                    >
                      E-mail
                    </Text>

                    <Text
                      style={
                        Style.accountValue
                      }
                    >
                      {email}
                    </Text>
                  </View>
                </View>
              </View>

              <TouchableOpacity
                style={Style.menuItem}
                activeOpacity={0.8}
                onPress={() =>
                  navigation.navigate(
                    'Page2'
                  )
                }
              >
                <View
                  style={[
                    Style.menuIcon,
                    Style.menuIconBlue,
                  ]}
                >
                  <Ionicons
                    name="stats-chart-outline"
                    size={22}
                    color="#60798A"
                  />
                </View>

                <View
                  style={
                    Style.menuTextArea
                  }
                >
                  <Text
                    style={
                      Style.menuTitle
                    }
                  >
                    Meu histórico
                  </Text>

                  <Text
                    style={
                      Style.menuSubtitle
                    }
                  >
                    Consulte suas medições
                  </Text>
                </View>

                <Ionicons
                  name="chevron-forward"
                  size={21}
                  color="#8B9583"
                />
              </TouchableOpacity>

              <TouchableOpacity
                style={Style.menuItem}
                activeOpacity={0.8}
                onPress={() =>
                  navigation.navigate(
                    'Page3'
                  )
                }
              >
                <View
                  style={[
                    Style.menuIcon,
                    Style.menuIconYellow,
                  ]}
                >
                  <Ionicons
                    name="notifications-outline"
                    size={22}
                    color="#9B772B"
                  />
                </View>

                <View
                  style={
                    Style.menuTextArea
                  }
                >
                  <Text
                    style={
                      Style.menuTitle
                    }
                  >
                    Alertas
                  </Text>

                  <Text
                    style={
                      Style.menuSubtitle
                    }
                  >
                    Veja os avisos da sua plantação
                  </Text>
                </View>

                <Ionicons
                  name="chevron-forward"
                  size={21}
                  color="#8B9583"
                />
              </TouchableOpacity>

              <View
                style={Style.menuItem}
              >
                <View
                  style={[
                    Style.menuIcon,
                    Style.menuIconGreen,
                  ]}
                >
                  <Ionicons
                    name="leaf-outline"
                    size={22}
                    color="#536B38"
                  />
                </View>

                <View
                  style={
                    Style.menuTextArea
                  }
                >
                  <Text
                    style={
                      Style.menuTitle
                    }
                  >
                    AgroControl
                  </Text>

                  <Text
                    style={
                      Style.menuSubtitle
                    }
                  >
                    Simples, prático e sustentável
                  </Text>
                </View>
              </View>
            </View>

            <TouchableOpacity
              style={
                Style.logoutButton
              }
              onPress={sair}
              activeOpacity={0.85}
            >
              <Ionicons
                name="log-out-outline"
                size={22}
                color="#FFFFFF"
              />

              <Text
                style={
                  Style.logoutText
                }
              >
                Sair da conta
              </Text>
            </TouchableOpacity>
          </>
        )}

        <Text style={Style.footer}>
          Simples • Prático • Sustentável
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}