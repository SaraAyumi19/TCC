import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

import { supabase } from '../../lib/supabase';
import Style from './style';

export default function Cadastro() {
  const navigation = useNavigation();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const [loading, setLoading] = useState(false);

  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  function limparMensagens() {
    if (errorMessage) {
      setErrorMessage('');
    }

    if (successMessage) {
      setSuccessMessage('');
    }
  }

  function handleNameChange(text) {
    setName(text);
    limparMensagens();
  }

  function handleEmailChange(text) {
    setEmail(text);
    limparMensagens();
  }

  function handlePasswordChange(text) {
    setPassword(text);
    limparMensagens();
  }

  async function handleSignUp() {
    const nomeLimpo = name.trim();
    const emailLimpo = email.trim();

    setErrorMessage('');
    setSuccessMessage('');

    if (!nomeLimpo) {
      setErrorMessage('Digite seu nome.');
      return;
    }

    if (!emailLimpo) {
      setErrorMessage('Digite seu e-mail.');
      return;
    }

    if (!emailLimpo.includes('@')) {
      setErrorMessage(
        'Digite um endereço de e-mail válido.'
      );
      return;
    }

    if (!password) {
      setErrorMessage('Digite uma senha.');
      return;
    }

    if (password.length < 6) {
      setErrorMessage(
        'A senha precisa ter pelo menos 6 caracteres.'
      );
      return;
    }

    try {
      setLoading(true);

      const { data, error } =
        await supabase.auth.signUp({
          email: emailLimpo,
          password,

          options: {
            data: {
              name: nomeLimpo,
            },
          },
        });

      console.log('CADASTRO DATA:', data);
      console.log('CADASTRO ERROR:', error);

      if (error) {
        const mensagem =
          error.message?.toLowerCase() || '';

        if (
          mensagem.includes('already registered') ||
          mensagem.includes(
            'already been registered'
          ) ||
          mensagem.includes(
            'user already registered'
          )
        ) {
          setErrorMessage(
            'Já existe uma conta com este e-mail.'
          );
        } else {
          setErrorMessage(
            'Não foi possível criar a conta. Verifique os dados informados.'
          );
        }

        return;
      }

      /*
        Se o Supabase criar uma sessão
        imediatamente, o RootNavigator
        detectará a sessão e abrirá o app.
      */

      if (data?.session) {
        setSuccessMessage(
          'Conta criada com sucesso!'
        );

        return;
      }

      /*
        Se a confirmação de e-mail estiver
        ativada no Supabase, normalmente
        não haverá sessão imediatamente.
      */

      setSuccessMessage(
        'Conta criada com sucesso! Verifique seu e-mail para confirmar o cadastro e depois faça login.'
      );

      setName('');
      setEmail('');
      setPassword('');
    } catch (error) {
      console.log(
        'Erro no cadastro:',
        error
      );

      setErrorMessage(
        'Não foi possível conectar. Tente novamente.'
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={Style.keyboard}
      behavior={
        Platform.OS === 'ios'
          ? 'padding'
          : undefined
      }
    >
      <ScrollView
        style={Style.scroll}
        contentContainerStyle={
          Style.scrollContainer
        }
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={true}
        nestedScrollEnabled={true}
      >
        <View style={Style.container}>
          {/* DECORAÇÃO */}

          <View style={Style.topDecoration} />

          {/* VOLTAR */}

          <TouchableOpacity
            style={Style.backButton}
            onPress={() =>
              navigation.goBack()
            }
            disabled={loading}
            activeOpacity={0.8}
          >
            <Ionicons
              name="arrow-back"
              size={25}
              color="#40552F"
            />
          </TouchableOpacity>

          {/* LOGO */}

          <View style={Style.logoArea}>
            <View style={Style.logoCircle}>
              <Image
                source={require(
                  '../../assets/icon.png'
                )}
                style={Style.logo}
                resizeMode="contain"
              />
            </View>

            <Text style={Style.appName}>
              AgroControl
            </Text>

            <Text style={Style.slogan}>
              Tecnologia simples para cuidar
              melhor da sua plantação.
            </Text>
          </View>

          {/* CARD */}

          <View style={Style.card}>
            <Text style={Style.title}>
              Criar conta
            </Text>

            <Text style={Style.subtitle}>
              Preencha seus dados para começar.
            </Text>

            {/* NOME */}

            <Text style={Style.label}>
              Nome
            </Text>

            <TextInput
              style={Style.input}
              placeholder="Digite seu nome"
              placeholderTextColor="#929B87"
              value={name}
              onChangeText={handleNameChange}
              autoCapitalize="words"
              autoCorrect={false}
              editable={!loading}
              returnKeyType="next"
            />

            {/* E-MAIL */}

            <Text style={Style.label}>
              E-mail
            </Text>

            <TextInput
              style={Style.input}
              placeholder="Digite seu e-mail"
              placeholderTextColor="#929B87"
              value={email}
              onChangeText={handleEmailChange}
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
              editable={!loading}
              returnKeyType="next"
            />

            {/* SENHA */}

            <Text style={Style.label}>
              Senha
            </Text>

            <TextInput
              style={Style.input}
              placeholder="Crie uma senha"
              placeholderTextColor="#929B87"
              secureTextEntry
              value={password}
              onChangeText={
                handlePasswordChange
              }
              autoCapitalize="none"
              autoCorrect={false}
              editable={!loading}
              returnKeyType="done"
              onSubmitEditing={
                handleSignUp
              }
            />

            <Text style={Style.passwordHint}>
              Use pelo menos 6 caracteres.
            </Text>

            {/* ERRO */}

            {errorMessage ? (
              <View
                style={Style.errorContainer}
              >
                <Ionicons
                  name="alert-circle-outline"
                  size={19}
                  color="#8A3E32"
                />

                <Text
                  style={Style.errorText}
                >
                  {errorMessage}
                </Text>
              </View>
            ) : null}

            {/* SUCESSO */}

            {successMessage ? (
              <View
                style={Style.successContainer}
              >
                <Ionicons
                  name="checkmark-circle-outline"
                  size={21}
                  color="#536B38"
                />

                <Text
                  style={Style.successText}
                >
                  {successMessage}
                </Text>
              </View>
            ) : null}

            {/* CADASTRAR */}

            <TouchableOpacity
              style={[
                Style.button,
                loading &&
                  Style.buttonDisabled,
              ]}
              onPress={handleSignUp}
              disabled={loading}
              activeOpacity={0.85}
            >
              {loading ? (
                <View
                  style={Style.loadingArea}
                >
                  <ActivityIndicator
                    color="#FFFFFF"
                    size="small"
                  />

                  <Text
                    style={
                      Style.loadingButtonText
                    }
                  >
                    Criando conta...
                  </Text>
                </View>
              ) : (
                <Text
                  style={Style.buttonText}
                >
                  Cadastrar
                </Text>
              )}
            </TouchableOpacity>

            {/* LOGIN */}

            <View style={Style.loginArea}>
              <Text
                style={Style.loginQuestion}
              >
                Já possui uma conta?
              </Text>

              <TouchableOpacity
                onPress={() =>
                  navigation.navigate(
                    'Login'
                  )
                }
                disabled={loading}
              >
                <Text
                  style={Style.loginLink}
                >
                  Entrar
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* RODAPÉ */}

          <Text style={Style.footer}>
            Simples • Prático • Sustentável
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}