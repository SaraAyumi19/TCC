import { StyleSheet } from 'react-native';

const Style = StyleSheet.create({

  keyboard: {
    flex: 1,
    backgroundColor: '#D9E2C3',
  },

  scroll: {
    flex: 1,
    backgroundColor: '#D9E2C3',
  },

  scrollContainer: {
    flexGrow: 1,
    paddingBottom: 40,
  },

  container: {
    width: '100%',

    backgroundColor: '#D9E2C3',

    paddingHorizontal: 24,
    paddingTop: 55,
    paddingBottom: 40,

    position: 'relative',
  },

  topDecoration: {
    position: 'absolute',

    width: 330,
    height: 330,

    borderRadius: 165,

    backgroundColor: '#607545',

    top: -190,
    right: -120,

    opacity: 0.55,
  },

  backButton: {
    width: 44,
    height: 44,

    borderRadius: 22,

    backgroundColor: '#F7F8F1',

    alignItems: 'center',
    justifyContent: 'center',

    marginBottom: 5,

    shadowColor: '#344123',

    shadowOffset: {
      width: 0,
      height: 3,
    },

    shadowOpacity: 0.12,
    shadowRadius: 5,

    elevation: 4,
  },

  logoArea: {
    width: '100%',

    alignItems: 'center',

    marginTop: 5,
    marginBottom: 25,
  },

  logoCircle: {
    width: 105,
    height: 105,

    borderRadius: 53,

    backgroundColor: '#F7F8F1',

    alignItems: 'center',
    justifyContent: 'center',

    marginBottom: 13,

    shadowColor: '#344123',

    shadowOffset: {
      width: 0,
      height: 5,
    },

    shadowOpacity: 0.15,
    shadowRadius: 8,

    elevation: 6,
  },

  logo: {
    width: 78,
    height: 78,
  },

  appName: {
    fontSize: 29,

    fontWeight: '800',

    color: '#40552F',

    letterSpacing: 0.3,
  },

  slogan: {
    maxWidth: 300,

    fontSize: 14,
    lineHeight: 20,

    color: '#5E6F50',

    textAlign: 'center',

    marginTop: 7,
  },


  card: {
    width: '100%',

    backgroundColor: '#F8F9F3',

    borderRadius: 26,

    paddingHorizontal: 22,
    paddingVertical: 26,

    shadowColor: '#344123',

    shadowOffset: {
      width: 0,
      height: 8,
    },

    shadowOpacity: 0.14,
    shadowRadius: 12,

    elevation: 8,
  },

  title: {
    fontSize: 25,

    fontWeight: '800',

    color: '#354827',

    textAlign: 'center',
  },

  subtitle: {
    fontSize: 14,

    color: '#7A876D',

    textAlign: 'center',

    marginTop: 6,
    marginBottom: 24,
  },

  label: {
    fontSize: 14,

    fontWeight: '600',

    color: '#4B5F3B',

    marginBottom: 7,
    marginLeft: 2,
  },

  input: {
    width: '100%',
    height: 54,

    backgroundColor: '#FFFFFF',

    borderRadius: 15,

    borderWidth: 1,
    borderColor: '#D5DDC8',

    paddingHorizontal: 16,

    fontSize: 15,

    color: '#334229',

    marginBottom: 16,
  },

  passwordHint: {
    fontSize: 12,

    color: '#7A876D',

    marginTop: -8,
    marginLeft: 3,
    marginBottom: 17,
  },


  errorContainer: {
    width: '100%',

    flexDirection: 'row',

    alignItems: 'center',

    backgroundColor: '#FDECE8',

    borderWidth: 1,
    borderColor: '#D99A8C',

    borderRadius: 12,

    paddingVertical: 11,
    paddingHorizontal: 12,

    marginBottom: 15,
  },

  errorText: {
    flex: 1,

    color: '#8A3E32',

    fontSize: 13,
    fontWeight: '600',

    lineHeight: 18,

    marginLeft: 7,
  },


  successContainer: {
    width: '100%',

    flexDirection: 'row',

    alignItems: 'center',

    backgroundColor: '#EAF0DF',

    borderWidth: 1,
    borderColor: '#B7C6A2',

    borderRadius: 12,

    paddingVertical: 11,
    paddingHorizontal: 12,

    marginBottom: 15,
  },

  successText: {
    flex: 1,

    color: '#40552F',

    fontSize: 13,
    fontWeight: '600',

    lineHeight: 18,

    marginLeft: 7,
  },


  button: {
    width: '100%',
    height: 56,

    borderRadius: 16,

    backgroundColor: '#536B38',

    alignItems: 'center',
    justifyContent: 'center',

    marginTop: 3,

    shadowColor: '#40542C',

    shadowOffset: {
      width: 0,
      height: 4,
    },

    shadowOpacity: 0.18,
    shadowRadius: 5,

    elevation: 4,
  },

  buttonDisabled: {
    opacity: 0.65,
  },

  buttonText: {
    color: '#FFFFFF',

    fontSize: 17,

    fontWeight: '700',
  },

  loadingArea: {
    flexDirection: 'row',

    alignItems: 'center',

    justifyContent: 'center',
  },

  loadingButtonText: {
    color: '#FFFFFF',

    fontSize: 17,

    fontWeight: '700',

    marginLeft: 9,
  },

  loginArea: {
    width: '100%',

    alignItems: 'center',

    justifyContent: 'center',

    marginTop: 22,
  },

  loginQuestion: {
    fontSize: 14,

    color: '#737E69',

    marginBottom: 5,
  },

  loginLink: {
    fontSize: 15,

    color: '#536B38',

    fontWeight: '800',
  },

  footer: {
    color: '#667558',

    textAlign: 'center',

    fontSize: 12,

    marginTop: 22,
    marginBottom: 20,

    letterSpacing: 0.4,
  },
});

export default Style;