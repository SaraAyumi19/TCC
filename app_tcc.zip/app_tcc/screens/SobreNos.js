import React from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import styles from './styleSN';

export default function SobreNos() {
  const navigation = useNavigation();

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#E4EBCF"
        translucent={false}
      />

      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {}
        <View style={styles.header}>

          <TouchableOpacity
            style={styles.backButton}
            activeOpacity={0.8}
            onPress={() => navigation.navigate('Page1')}
          >
            <Ionicons
              name="arrow-back"
              size={24}
              color="#536B38"
            />
          </TouchableOpacity>

          <View style={styles.headerTextArea}>
            <View style={styles.logoContainer}>
              <Image
                source={require('../assets/icon.png')}
                style={styles.logo}
                resizeMode="contain"
              />
            </View>

            <Text style={styles.title}>
              Sobre nós
            </Text>
          </View>

          <View style={styles.headerSpacer} />

        </View>

        {}
        <View style={styles.card}>
          <View style={styles.iconCircle}>
            <Text style={styles.icon}>👥</Text>
          </View>

          <View style={styles.cardContent}>
            <Text style={styles.cardTitle}>
              Quem somos
            </Text>

            <Text style={styles.text}>
              O AgroControl é um projeto desenvolvido para auxiliar
              pequenos produtores rurais no monitoramento da umidade
              do solo e no controle da irrigação.
            </Text>

            <Text style={styles.text}>
              Nosso propósito é utilizar a tecnologia de forma acessível,
              prática e sustentável para facilitar o acompanhamento
              das condições da plantação.
            </Text>
          </View>
        </View>

        {/* Como funciona */}
        <View style={styles.card}>
          <View style={styles.iconCircle}>
            <Text style={styles.icon}>💧</Text>
          </View>

          <View style={styles.cardContent}>
            <Text style={styles.cardTitle}>
              Como funciona
            </Text>

            <Text style={styles.text}>
              O sistema utiliza sensores para coletar informações
              sobre a umidade do solo. Esses dados são processados
              pelo microcontrolador ESP32 e disponibilizados no
              aplicativo.
            </Text>

            <Text style={styles.text}>
              Quando a umidade estiver abaixo do limite estabelecido,
              o sistema poderá acionar automaticamente a irrigação.
            </Text>
          </View>
        </View>

        {}
        <View style={styles.card}>
          <View style={styles.iconCircle}>
            <Text style={styles.icon}>⚙️</Text>
          </View>

          <View style={styles.cardContent}>
            <Text style={styles.cardTitle}>
              Tecnologia
            </Text>

            <Text style={styles.text}>
              O projeto integra hardware e software para tornar
              o monitoramento agrícola mais acessível.
            </Text>

            <View style={styles.techList}>
              <Text style={styles.techItem}>
                • Arduino ESP32
              </Text>

              <Text style={styles.techItem}>
                • Sensores de umidade
              </Text>

              <Text style={styles.techItem}>
                • Aplicativo mobile
              </Text>

              <Text style={styles.techItem}>
                • React Native
              </Text>

              <Text style={styles.techItem}>
                • Supabase
              </Text>
            </View>
          </View>
        </View>

        {}
        <View style={styles.card}>
          <View style={styles.iconCircle}>
            <Text style={styles.icon}>🌱</Text>
          </View>

          <View style={styles.cardContent}>
            <Text style={styles.cardTitle}>
              Sustentabilidade
            </Text>

            <Text style={styles.text}>
              O AgroControl busca contribuir para uma utilização
              mais consciente da água na agricultura.
            </Text>

            <Text style={styles.text}>
              Ao acompanhar a umidade do solo e automatizar a
              irrigação, o sistema busca reduzir desperdícios e
              promover um manejo mais eficiente dos recursos hídricos.
            </Text>
          </View>
        </View>

        <View style={styles.teamCard}>
          <Text style={styles.teamTitle}>
            Desenvolvido por
          </Text>
          <Text style={styles.teamText}>
            Maria Clara do Santo
          </Text>
          <Text style={styles.teamText}>
            Maria Fernanda Oliveira da Costa
          </Text>
          <Text style={styles.teamText}>
            Maria Luísa Souza Vieira
          </Text>
          <Text style={styles.teamText}>
            Sara Ayumi Matsumoto
          </Text>
          <Text style={styles.school}>
            Etec Rodrigues de Abreu
          </Text>
        </View>

        <Text style={styles.footer}>
          Simples • Prático • Sustentável
        </Text>

      </ScrollView>
    </SafeAreaView>
  );
}
