import React, {
  useCallback,
  useEffect,
  useState,
} from 'react';

import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  SafeAreaView,
  ActivityIndicator,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';

import { supabase } from '../lib/supabase';

import Style from './styleP2';

export default function Page2() {
  const navigation = useNavigation();

  const SENSOR_ID = 'sensor_01';

  const [medicoes, setMedicoes] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');

  async function carregarMedicoes() {
    try {
      setCarregando(true);
      setErro('');

      const {
        data,
        error,
      } = await supabase
        .from('leituras_umidade')
        .select('*')
        .eq('sensor_id', SENSOR_ID)
        .order('created_at', {
          ascending: false,
        })
        .limit(100);

      if (error) {
        throw error;
      }

      setMedicoes(data || []);

    } catch (error) {
      console.log(
        'Erro ao carregar histórico:',
        error
      );

      setErro(
        error?.message ||
        'Não foi possível carregar o histórico.'
      );

      setMedicoes([]);

    } finally {
      setCarregando(false);
    }
  }

  useEffect(() => {
    carregarMedicoes();
  }, []);

  useFocusEffect(
    useCallback(() => {
      carregarMedicoes();
    }, [])
  );

  function formatarData(dataString) {
    if (!dataString) {
      return '--/--/----';
    }

    try {
      return new Date(
        dataString
      ).toLocaleDateString(
        'pt-BR',
        {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric',
        }
      );
    } catch {
      return '--/--/----';
    }
  }

  function formatarHora(dataString) {
    if (!dataString) {
      return '--:--:--';
    }

    try {
      return new Date(
        dataString
      ).toLocaleTimeString(
        'pt-BR',
        {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }
      );
    } catch {
      return '--:--:--';
    }
  }

  return (
    <SafeAreaView style={Style.safeArea}>

      <StatusBar
        barStyle="dark-content"
        backgroundColor="#F4F6EE"
        translucent={false}
      />

      <ScrollView
        style={Style.scroll}
        contentContainerStyle={Style.scrollContent}
        showsVerticalScrollIndicator={true}
      >

        {/* HEADER */}

        <View style={Style.header}>

          <TouchableOpacity
            style={Style.backButton}
            activeOpacity={0.8}
            onPress={() =>
              navigation.navigate('Page1')
            }
          >
            <Ionicons
              name="arrow-back"
              size={24}
              color="#536B38"
            />
          </TouchableOpacity>

          <View style={Style.headerTextArea}>

            <Text style={Style.title}>
              Histórico
            </Text>

            <Text style={Style.subtitle}>
              Acompanhe as medições da sua plantação.
            </Text>

          </View>

          <View style={Style.headerSpacer} />

        </View>

        {/* RESUMO */}

        <View style={Style.summaryCard}>

          <View style={Style.summaryIcon}>

            <Ionicons
              name="stats-chart-outline"
              size={28}
              color="#536B38"
            />

          </View>

          <View style={Style.summaryTextArea}>

            <Text style={Style.summaryTitle}>
              Histórico de umidade
            </Text>

            <Text style={Style.summaryText}>
              As leituras reais do sensor são
              carregadas diretamente do sistema.
            </Text>

          </View>

        </View>

        {/* TÍTULO */}

        <View style={Style.sectionHeader}>

          <Text style={Style.sectionTitle}>
            Medições
          </Text>

          <Ionicons
            name="water-outline"
            size={24}
            color="#536B38"
          />

        </View>

        {/* CARREGANDO */}

        {carregando ? (

          <View
            style={{
              paddingVertical: 40,
              alignItems: 'center',
            }}
          >

            <ActivityIndicator
              size="large"
              color="#536B38"
            />

            <Text
              style={{
                marginTop: 12,
                color: '#788078',
              }}
            >
              Carregando medições...
            </Text>

          </View>

        ) : erro ? (

          /* ERRO */

          <View style={Style.emptyCard}>

            <View style={Style.emptyIcon}>

              <Ionicons
                name="alert-circle-outline"
                size={42}
                color="#8A3E32"
              />

            </View>

            <Text style={Style.emptyTitle}>
              Não foi possível carregar
            </Text>

            <Text style={Style.emptyText}>
              {erro}
            </Text>

            <TouchableOpacity
              onPress={carregarMedicoes}
              style={{
                marginTop: 16,
                backgroundColor: '#536B38',
                paddingHorizontal: 22,
                paddingVertical: 10,
                borderRadius: 10,
              }}
            >

              <Text
                style={{
                  color: '#FFFFFF',
                  fontWeight: '600',
                }}
              >
                Tentar novamente
              </Text>

            </TouchableOpacity>

          </View>

        ) : medicoes.length === 0 ? (

          /* SEM MEDIÇÕES */

          <View style={Style.emptyCard}>

            <View style={Style.emptyIcon}>

              <Ionicons
                name="file-tray-outline"
                size={42}
                color="#788B5A"
              />

            </View>

            <Text style={Style.emptyTitle}>
              Nenhuma medição disponível
            </Text>

            <Text style={Style.emptyText}>
              O ESP32 ainda não enviou nenhuma
              leitura para o sensor sensor_01.
            </Text>

          </View>

        ) : (

          /* MEDIÇÕES */

          medicoes.map(
            (medicao, index) => {

              const umidade =
                Number(medicao.umidade);

              return (

                <View
                  key={
                    medicao.id ||
                    `${medicao.created_at}-${index}`
                  }
                  style={Style.measurementCard}
                >

                  <View
                    style={Style.measurementTop}
                  >

                    <View>

                      <Text
                        style={
                          Style.measurementDate
                        }
                      >
                        {formatarData(
                          medicao.created_at
                        )}
                      </Text>

                      <Text
                        style={
                          Style.measurementTime
                        }
                      >
                        {formatarHora(
                          medicao.created_at
                        )}
                      </Text>

                    </View>

                    <View
                      style={
                        Style.measurementBadge
                      }
                    >

                      <Ionicons
                        name="water-outline"
                        size={17}
                        color="#536B38"
                      />

                      <Text
                        style={
                          Style.measurementValue
                        }
                      >
                        {Number.isFinite(umidade)
                          ? `${umidade.toFixed(1)}%`
                          : '--'}
                      </Text>

                    </View>

                  </View>

                </View>

              );
            }
          )

        )}

        {/* RODAPÉ */}

        <Text style={Style.footer}>
          Simples • Prático • Sustentável
        </Text>

      </ScrollView>

    </SafeAreaView>
  );
}
