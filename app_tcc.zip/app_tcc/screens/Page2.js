import React from 'react';

import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  SafeAreaView,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

import Style from './styleP2';

export default function Page2() {
  const navigation = useNavigation();

  const medicoes = [];

  return (
    <SafeAreaView style={Style.safeArea}>
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#F4F6EE"
        translucent={false}
      />

      <ScrollView
        style={Style.scroll}
        contentContainerStyle={Style.scrollContent}
        showsVerticalScrollIndicator={true}
      >
        <View style={Style.header}>
          <TouchableOpacity
            style={Style.backButton}
            activeOpacity={0.8}
            onPress={() => navigation.navigate('Page1')}
          >
            <Ionicons
              name="arrow-back"
              size={24}
              color="#536B38"
            />
          </TouchableOpacity>

          <View style={Style.headerTextArea}>
            <Text style={Style.title}>
              Histórico
            </Text>

            <Text style={Style.subtitle}>
              Acompanhe as medições da sua plantação.
            </Text>
          </View>

          <View style={Style.headerSpacer} />
        </View>

        <View style={Style.summaryCard}>
          <View style={Style.summaryIcon}>
            <Ionicons
              name="stats-chart-outline"
              size={28}
              color="#536B38"
            />
          </View>

          <View style={Style.summaryTextArea}>
            <Text style={Style.summaryTitle}>
              Histórico de umidade
            </Text>

            <Text style={Style.summaryText}>
              As leituras do sensor aparecerão aqui quando o sistema estiver conectado.
            </Text>
          </View>
        </View>

        <View style={Style.sectionHeader}>
          <Text style={Style.sectionTitle}>
            Medições
          </Text>

          <Ionicons
            name="water-outline"
            size={24}
            color="#536B38"
          />
        </View>

        {medicoes.length === 0 ? (
          <View style={Style.emptyCard}>
            <View style={Style.emptyIcon}>
              <Ionicons
                name="file-tray-outline"
                size={42}
                color="#788B5A"
              />
            </View>

            <Text style={Style.emptyTitle}>
              Nenhuma medição disponível
            </Text>

            <Text style={Style.emptyText}>
              Quando o sensor de umidade estiver conectado, as leituras reais serão exibidas nesta tela.
            </Text>
          </View>
        ) : (
          medicoes.map((medicao, index) => (
            <View
              key={index}
              style={Style.measurementCard}
            >
              <View style={Style.measurementTop}>
                <View>
                  <Text style={Style.measurementDate}>
                    {medicao.data}
                  </Text>

                  <Text style={Style.measurementTime}>
                    {medicao.hora}
                  </Text>
                </View>

                <View style={Style.measurementBadge}>
                  <Ionicons
                    name="water-outline"
                    size={17}
                    color="#536B38"
                  />

                  <Text style={Style.measurementValue}>
                    {medicao.umidade}%
                  </Text>
                </View>
              </View>
            </View>
          ))
        )}

        <Text style={Style.footer}>
          Simples • Prático • Sustentável
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}