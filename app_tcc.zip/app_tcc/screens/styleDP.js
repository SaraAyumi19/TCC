import {
  StyleSheet,
  Platform,
  StatusBar,
} from 'react-native';

const Style = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#F4F6EE',
    paddingTop:
      Platform.OS === 'android'
        ? StatusBar.currentHeight || 0
        : 0,
  },

  scroll: {
    flex: 1,
    backgroundColor: '#F4F6EE',
  },

  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 22,
    paddingTop: 18,
    paddingBottom: 45,
  },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  backButton: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: '#E5ECD9',
    alignItems: 'center',
    justifyContent: 'center',
  },

  headerTitle: {
    flex: 1,
    fontSize: 21,
    fontWeight: '800',
    color: '#40552F',
    textAlign: 'center',
  },

  headerSpacer: {
    width: 46,
    height: 46,
  },

  loading: {
    marginTop: 90,
  },

  photoCard: {
    width: '100%',
    height: 245,
    borderRadius: 28,
    marginTop: 27,
    overflow: 'hidden',
    backgroundColor: '#D9E2C3',
    position: 'relative',
    elevation: 4,
    shadowColor: '#354427',
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.12,
    shadowRadius: 8,
  },

  profilePhoto: {
    width: '100%',
    height: '100%',
  },

  photoOverlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: 100,
    backgroundColor:
      'rgba(24, 38, 20, 0.38)',
  },

  photoTextArea: {
    position: 'absolute',
    left: 20,
    right: 20,
    bottom: 18,
  },

  photoName: {
    fontSize: 23,
    fontWeight: '800',
    color: '#FFFFFF',
  },

  photoEmail: {
    fontSize: 13,
    color: '#F3F6ED',
    marginTop: 4,
  },

  noPhotoArea: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },

  noPhotoText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#536B38',
    marginTop: 10,
  },

  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 30,
    marginBottom: 14,
  },

  sectionTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: '#40552F',
  },

  sectionSubtitle: {
    fontSize: 12,
    color: '#7B8871',
    marginTop: 3,
  },

  card: {
    width: '100%',
    minHeight: 86,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E0E5D8',
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 11,
    flexDirection: 'row',
    alignItems: 'center',
    elevation: 2,
  },

  readOnlyCard: {
    width: '100%',
    minHeight: 82,
    backgroundColor: '#F8F9F4',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E0E5D8',
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 11,
    flexDirection: 'row',
    alignItems: 'center',
  },

  iconArea: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#E7EDD9',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 13,
  },

  textArea: {
    flex: 1,
  },

  label: {
    fontSize: 12,
    color: '#7B8871',
    marginBottom: 2,
  },

  input: {
    width: '100%',
    minHeight: 38,
    paddingVertical: 4,
    paddingHorizontal: 0,
    fontSize: 16,
    fontWeight: '700',
    color: '#40552F',
  },

  readOnlyValue: {
    fontSize: 15,
    fontWeight: '700',
    color: '#40552F',
    marginTop: 3,
  },

  saveButton: {
    width: '100%',
    minHeight: 57,
    borderRadius: 17,
    backgroundColor: '#536B38',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 13,
  },

  saveButtonDisabled: {
    opacity: 0.5,
  },

  saveButtonText: {
    fontSize: 15,
    fontWeight: '800',
    color: '#FFFFFF',
    marginLeft: 8,
  },

  securityCard: {
    width: '100%',
    backgroundColor: '#EEF2E5',
    borderRadius: 18,
    padding: 16,
    marginTop: 18,
    flexDirection: 'row',
    alignItems: 'flex-start',
  },

  securityText: {
    flex: 1,
    fontSize: 12,
    lineHeight: 18,
    color: '#68785A',
    marginLeft: 11,
  },

  footer: {
    fontSize: 12,
    color: '#7A876D',
    textAlign: 'center',
    marginTop: 31,
    marginBottom: 20,
  },
});

export default Style;
