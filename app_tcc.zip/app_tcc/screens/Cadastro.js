import React, {
  useState,
} from "react";

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
} from "react-native";

import {
  useNavigation,
} from "@react-navigation/native";

import { supabase } from "../lib/supabase";

import Style from "../styles/styles";

export default function Cadastro() {
  const navigation =
    useNavigation();

  const [nome, setNome] =
    useState("");

  const [email, setEmail] =
    useState("");

  const [senha, setSenha] =
    useState("");

  const [loading, setLoading] =
    useState(false);

  async function cadastrar() {
    if (
      !nome ||
      !email ||
      !senha
    ) {
      Alert.alert(
        "Atenção",
        "Preencha todos os campos."
      );

      return;
    }

    if (senha.length < 6) {
      Alert.alert(
        "Atenção",
        "A senha deve ter pelo menos 6 caracteres."
      );

      return;
    }

    setLoading(true);

    const {
      data,
      error,
    } =
      await supabase.auth.signUp({
        email: email.trim(),
        password: senha,

        options: {
          data: {
            name: nome.trim(),
          },
        },
      });

    setLoading(false);

    if (error) {
      Alert.alert(
        "Erro",
        error.message
      );

      return;
    }

    Alert.alert(
      "Conta criada!",
      "Sua conta foi criada com sucesso.",
      [
        {
          text: "Continuar",
          onPress: () =>
            navigation.replace(
              "Page1"
            ),
        },
      ]
    );
  }

  return (
    <View style={Style.authContainer}>

      <View style={Style.logo}>
        <Text style={Style.logoTexto}>
          Criar conta
        </Text>

        <Text
          style={Style.logoSubtexto}
        >
          Comece a usar o Clima
        </Text>
      </View>

      <TextInput
        style={Style.authInput}
        placeholder="Nome"
        placeholderTextColor="#999"
        value={nome}
        onChangeText={setNome}
      />

      <TextInput
        style={Style.authInput}
        placeholder="E-mail"
        placeholderTextColor="#999"
        keyboardType="email-address"
        autoCapitalize="none"
        value={email}
        onChangeText={setEmail}
      />

      <TextInput
        style={Style.authInput}
        placeholder="Senha"
        placeholderTextColor="#999"
        secureTextEntry
        value={senha}
        onChangeText={setSenha}
      />

      <TouchableOpacity
        style={Style.button}
        onPress={cadastrar}
        disabled={loading}
      >
        <Text style={Style.buttonText}>
          {loading
            ? "Criando..."
            : "Criar conta"}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() =>
          navigation.goBack()
        }
      >
        <Text style={Style.link}>
          Já tenho uma conta
        </Text>
      </TouchableOpacity>

    </View>
  );
}