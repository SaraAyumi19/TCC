import {
  StyleSheet,
  Platform,
  StatusBar,
} from 'react-native';

const Style = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#F4F6EE',
    paddingTop:
      Platform.OS === 'android'
        ? StatusBar.currentHeight || 0
        : 0,
  },

  scroll: {
    flex: 1,
    backgroundColor: '#F4F6EE',
  },

  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 22,
    paddingTop: 22,
    paddingBottom: 45,
  },

  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },

  backButton: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: '#E5ECD9',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 13,
  },

  headerTextArea: {
    flex: 1,
  },

  headerSpacer: {
    width: 46,
  },

  title: {
    fontSize: 28,
    fontWeight: '800',
    color: '#40552F',
  },

  subtitle: {
    fontSize: 14,
    color: '#7C8872',
    marginTop: 5,
    lineHeight: 20,
  },

  summaryCard: {
    width: '100%',
    backgroundColor: '#D9E2C3',
    borderRadius: 24,
    padding: 20,
    marginTop: 28,
    flexDirection: 'row',
    alignItems: 'center',
    elevation: 3,
    shadowColor: '#354427',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.08,
    shadowRadius: 7,
  },

  summaryIcon: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: '#F7F8F1',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
  },

  summaryTextArea: {
    flex: 1,
  },

  summaryTitle: {
    fontSize: 17,
    fontWeight: '800',
    color: '#40552F',
  },

  summaryText: {
    fontSize: 13,
    color: '#68785A',
    lineHeight: 19,
    marginTop: 4,
  },

  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 30,
    marginBottom: 13,
  },

  sectionTitle: {
    fontSize: 21,
    fontWeight: '800',
    color: '#40552F',
  },

  emptyCard: {
    width: '100%',
    backgroundColor: '#FFFFFF',
    borderRadius: 22,
    borderWidth: 1,
    borderColor: '#E0E5D8',
    paddingHorizontal: 25,
    paddingVertical: 35,
    alignItems: 'center',
    elevation: 2,
  },

  emptyIcon: {
    width: 76,
    height: 76,
    borderRadius: 38,
    backgroundColor: '#E7EDD9',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 18,
  },

  emptyTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: '#40552F',
    textAlign: 'center',
  },

  emptyText: {
    fontSize: 14,
    lineHeight: 21,
    color: '#7A876D',
    textAlign: 'center',
    marginTop: 8,
  },

  alertCard: {
    width: '100%',
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E0E5D8',
    padding: 17,
    marginBottom: 11,
    flexDirection: 'row',
    elevation: 2,
  },

  alertIcon: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: '#F4EACD',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 13,
  },

  alertTextArea: {
    flex: 1,
  },

  alertTitle: {
    fontSize: 15,
    fontWeight: '800',
    color: '#40552F',
  },

  alertDescription: {
    fontSize: 13,
    lineHeight: 19,
    color: '#74806C',
    marginTop: 4,
  },

  alertDate: {
    fontSize: 11,
    color: '#929B8A',
    marginTop: 7,
  },

  infoCard: {
    width: '100%',
    backgroundColor: '#EEF2E5',
    borderRadius: 18,
    padding: 16,
    marginTop: 22,
    flexDirection: 'row',
    alignItems: 'flex-start',
  },

  infoText: {
    flex: 1,
    fontSize: 13,
    lineHeight: 19,
    color: '#68785A',
    marginLeft: 10,
  },

  footer: {
    fontSize: 12,
    color: '#7A876D',
    textAlign: 'center',
    marginTop: 31,
    marginBottom: 20,
  },
});

export default Style;
