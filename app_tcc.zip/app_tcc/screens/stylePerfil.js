import {
  StyleSheet,
  Platform,
  StatusBar,
} from 'react-native';

const Style = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#F4F6EE',
    paddingTop:
      Platform.OS === 'android'
        ? StatusBar.currentHeight || 0
        : 0,
  },

  scroll: {
    flex: 1,
    backgroundColor: '#F4F6EE',
  },

  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 22,
    paddingTop: 18,
    paddingBottom: 45,
  },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  backButton: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: '#E5ECD9',
    alignItems: 'center',
    justifyContent: 'center',
  },

  headerTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: '#40552F',
  },

  headerSpacer: {
    width: 46,
    height: 46,
  },

  loading: {
    marginTop: 90,
  },

  profileCard: {
    width: '100%',
    backgroundColor: '#D9E2C3',
    borderRadius: 28,
    marginTop: 25,
    paddingHorizontal: 20,
    paddingVertical: 27,
    shadowColor: '#354427',
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },

  profileTop: {
    alignItems: 'center',
  },

  photoArea: {
    alignItems: 'center',
    justifyContent: 'center',
  },

  avatarButton: {
    width: 116,
    height: 116,
    borderRadius: 58,
    position: 'relative',
  },

  avatarImage: {
    width: 116,
    height: 116,
    borderRadius: 58,
    borderWidth: 4,
    borderColor: '#FFFFFF',
  },

  avatarPlaceholder: {
    width: 116,
    height: 116,
    borderRadius: 58,
    backgroundColor: '#F7F8F1',
    borderWidth: 4,
    borderColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },

  cameraButton: {
    position: 'absolute',
    right: 1,
    bottom: 4,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#536B38',
    borderWidth: 3,
    borderColor: '#D9E2C3',
    alignItems: 'center',
    justifyContent: 'center',
  },

  name: {
    fontSize: 23,
    fontWeight: '800',
    color: '#354827',
    textAlign: 'center',
    marginTop: 15,
  },

  email: {
    fontSize: 14,
    color: '#68785A',
    textAlign: 'center',
    marginTop: 5,
  },

  changePhotoButton: {
    minHeight: 42,
    paddingHorizontal: 18,
    borderRadius: 21,
    backgroundColor: '#F7F8F1',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 16,
  },

  changePhotoText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#536B38',
    marginLeft: 7,
  },

  welcomeText: {
    fontSize: 23,
    fontWeight: '800',
    color: '#40552F',
    marginTop: 29,
  },

  welcomeDescription: {
    fontSize: 14,
    lineHeight: 20,
    color: '#7A876D',
    marginTop: 5,
    marginBottom: 17,
  },

  menuArea: {
    width: '100%',
  },

  menuItem: {
    width: '100%',
    minHeight: 78,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E0E5D8',
    paddingHorizontal: 15,
    paddingVertical: 13,
    marginBottom: 11,
    flexDirection: 'row',
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#354427',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 5,
  },

  menuIcon: {
    width: 46,
    height: 46,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 13,
  },

  menuIconGreen: {
    backgroundColor: '#E7EDD9',
  },

  menuIconBlue: {
    backgroundColor: '#E5EDF0',
  },

  menuIconYellow: {
    backgroundColor: '#F4EACD',
  },

  menuTextArea: {
    flex: 1,
  },

  menuTitle: {
    fontSize: 15,
    fontWeight: '800',
    color: '#40552F',
  },

  menuSubtitle: {
    fontSize: 12,
    lineHeight: 17,
    color: '#7C8872',
    marginTop: 3,
  },

  accountInfo: {
    width: '100%',
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E0E5D8',
    paddingHorizontal: 16,
    paddingVertical: 5,
    marginTop: -3,
    marginBottom: 11,
  },

  accountRow: {
    minHeight: 68,
    flexDirection: 'row',
    alignItems: 'center',
  },

  accountIcon: {
    width: 39,
    height: 39,
    borderRadius: 20,
    backgroundColor: '#EEF2E5',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },

  accountTextArea: {
    flex: 1,
  },

  accountLabel: {
    fontSize: 11,
    color: '#8A9481',
  },

  accountValue: {
    fontSize: 14,
    fontWeight: '700',
    color: '#40552F',
    marginTop: 3,
  },

  accountDivider: {
    height: 1,
    backgroundColor: '#E8EBE3',
  },

  logoutButton: {
    width: '100%',
    minHeight: 56,
    borderRadius: 17,
    backgroundColor: '#536B38',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 17,
  },

  logoutText: {
    fontSize: 15,
    fontWeight: '800',
    color: '#FFFFFF',
    marginLeft: 8,
  },

  footer: {
    fontSize: 12,
    color: '#7A876D',
    textAlign: 'center',
    marginTop: 31,
    marginBottom: 20,
  },
});

export default Style;