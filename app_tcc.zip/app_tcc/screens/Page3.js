import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import Style from './styleP3';

export default function Page3() {
  const navigation = useNavigation();

  const alertas = [];
  return (
    <SafeAreaView style={Style.safeArea}>
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#F4F6EE"
        translucent={false}
      />

      <ScrollView
        style={Style.scroll}
        contentContainerStyle={Style.scrollContent}
        showsVerticalScrollIndicator={true}
      >
        <View style={Style.header}>
          <TouchableOpacity
            style={Style.backButton}
            activeOpacity={0.8}
            onPress={() => navigation.goBack()}
          >
            <Ionicons
              name="arrow-back"
              size={24}
              color="#536B38"
            />
          </TouchableOpacity>

          <View style={Style.headerTextArea}>
            <Text style={Style.title}>
              Alertas
            </Text>

            <Text style={Style.subtitle}>
              Acompanhe os avisos importantes da sua plantação.
            </Text>
          </View>

          <View style={Style.headerSpacer} />
        </View>

        <View style={Style.summaryCard}>
          <View style={Style.summaryIcon}>
            <Ionicons
              name="notifications-outline"
              size={29}
              color="#536B38"
            />
          </View>

          <View style={Style.summaryTextArea}>
            <Text style={Style.summaryTitle}>
              Central de alertas
            </Text>

            <Text style={Style.summaryText}>
              Os avisos serão gerados a partir dos dados reais do sistema.
            </Text>
          </View>
        </View>

        <View style={Style.sectionHeader}>
          <Text style={Style.sectionTitle}>
            Avisos
          </Text>

          <Ionicons
            name="warning-outline"
            size={24}
            color="#536B38"
          />
        </View>

        {alertas.length === 0 ? (
          <View style={Style.emptyCard}>
            <View style={Style.emptyIcon}>
              <Ionicons
                name="checkmark-circle-outline"
                size={44}
                color="#788B5A"
              />
            </View>

            <Text style={Style.emptyTitle}>
              Nenhum alerta disponível
            </Text>

            <Text style={Style.emptyText}>
              Quando o sistema estiver conectado, os alertas reais aparecerão aqui.
            </Text>
          </View>
        ) : (
          alertas.map((alerta, index) => (
            <View
              key={index}
              style={Style.alertCard}
            >
              <View style={Style.alertIcon}>
                <Ionicons
                  name="warning-outline"
                  size={24}
                  color="#9B772B"
                />
              </View>

              <View style={Style.alertTextArea}>
                <Text style={Style.alertTitle}>
                  {alerta.titulo}
                </Text>

                <Text style={Style.alertDescription}>
                  {alerta.descricao}
                </Text>

                <Text style={Style.alertDate}>
                  {alerta.data} • {alerta.hora}
                </Text>
              </View>
            </View>
          ))
        )}

        <View style={Style.infoCard}>
          <Ionicons
            name="information-circle-outline"
            size={25}
            color="#536B38"
          />

          <Text style={Style.infoText}>
            Os alertas poderão informar baixa umidade do solo, acionamento da irrigação e outras condições importantes.
          </Text>
        </View>

        <Text style={Style.footer}>
          Simples • Prático • Sustentável
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}
