import React from "react";

import {
  View,
  Text,
  TouchableOpacity,
} from "react-native";

import {
  useNavigation,
} from "@react-navigation/native";

import {
  Ionicons,
} from "@expo/vector-icons";

import Style, {
  colors,
} from "../styles/styles";

export default function Page3() {
  const navigation =
    useNavigation();

  return (
    <View style={Style.container}>

      <View style={Style.header}>

        <TouchableOpacity
          style={Style.headerButton}
          onPress={() =>
            navigation.goBack()
          }
        >
          <Ionicons
            name="arrow-back"
            size={26}
            color={
              colors.brownDark
            }
          />
        </TouchableOpacity>

        <Text style={Style.titulo}>
          Página 3
        </Text>

        <View
          style={{
            width: 45,
          }}
        />

      </View>

      <View
        style={{
          flex: 1,
          alignItems:
            "center",
          justifyContent:
            "center",
        }}
      >
        <Text
          style={{
            fontSize: 25,
            fontWeight:
              "bold",
            color:
              colors.brownDark,
          }}
        >
          Página 3
        </Text>

        <Text
          style={{
            marginTop: 10,
            color:
              colors.gray,
          }}
        >
          Conteúdo da página 3
        </Text>
      </View>

    </View>
  );
}