import {
  StyleSheet,
  Platform,
  StatusBar,
} from 'react-native';

const Style = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#F4F6EE',
    paddingTop:
      Platform.OS === 'android'
        ? StatusBar.currentHeight || 0
        : 0,
  },

  scroll: {
    flex: 1,
    backgroundColor: '#F4F6EE',
  },

  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 22,
    paddingTop: 22,
    paddingBottom: 45,
  },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  headerTextArea: {
    flex: 1,
  },

  appName: {
    fontSize: 29,
    fontWeight: '800',
    color: '#40552F',
  },

  hello: {
    fontSize: 20,
    fontWeight: '600',
    color: '#68785A',
    marginTop: 4,
  },

  userLoading: {
    marginTop: 8,
    alignSelf: 'flex-start',
  },

  logoutButton: {
    width: 54,
    height: 54,
    borderRadius: 27,
    backgroundColor: '#E5ECD9',
    alignItems: 'center',
    justifyContent: 'center',
  },

  intro: {
    fontSize: 15,
    lineHeight: 21,
    color: '#7C8872',
    marginTop: 13,
    marginBottom: 25,
  },

  mainCard: {
    width: '100%',
    backgroundColor: '#D9E2C3',
    borderRadius: 27,
    padding: 22,
    shadowColor: '#354427',
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },

  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  cardHeaderText: {
    flex: 1,
  },

  mainIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#F7F8F1',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 13,
  },

  mainCardLabel: {
    fontSize: 18,
    fontWeight: '800',
    color: '#3F522F',
  },

  mainCardDescription: {
    fontSize: 13,
    color: '#758267',
    marginTop: 3,
  },

  noReading: {
    fontSize: 24,
    fontWeight: '800',
    color: '#455938',
    textAlign: 'center',
    marginTop: 30,
    marginBottom: 12,
  },

  moistureValue: {
    fontSize: 58,
    fontWeight: '800',
    color: '#354827',
    textAlign: 'center',
    marginVertical: 23,
  },

  infoCard: {
    width: '100%',
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 18,
    marginTop: 16,
    borderWidth: 1,
    borderColor: '#E0E5D8',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    elevation: 2,
  },

  infoLeft: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },

  infoIcon: {
    width: 47,
    height: 47,
    borderRadius: 24,
    backgroundColor: '#E7EDD9',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 13,
  },

  infoTextArea: {
    flex: 1,
  },

  infoLabel: {
    fontSize: 13,
    color: '#7B8871',
  },

  infoValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#40552F',
    marginTop: 3,
  },

  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 28,
    marginBottom: 13,
  },

  sectionTitle: {
    fontSize: 21,
    fontWeight: '800',
    color: '#40552F',
  },

  weatherCard: {
    width: '100%',
    backgroundColor: '#FFFFFF',
    borderRadius: 22,
    padding: 18,
    borderWidth: 1,
    borderColor: '#E0E5D8',
    elevation: 2,
  },

  weatherHelp: {
    fontSize: 14,
    color: '#65745A',
    marginBottom: 13,
  },

  searchArea: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  cityInput: {
    flex: 1,
    height: 54,
    backgroundColor: '#F7F8F3',
    borderRadius: 15,
    borderWidth: 1,
    borderColor: '#D8DECE',
    paddingHorizontal: 15,
    fontSize: 15,
    color: '#354827',
    marginRight: 9,
  },

  searchButton: {
    width: 54,
    height: 54,
    borderRadius: 15,
    backgroundColor: '#536B38',
    alignItems: 'center',
    justifyContent: 'center',
  },

  searchButtonDisabled: {
    opacity: 0.65,
  },

  errorArea: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FDECE8',
    borderWidth: 1,
    borderColor: '#D99A8C',
    borderRadius: 12,
    padding: 11,
    marginTop: 12,
  },

  errorText: {
    flex: 1,
    color: '#8A3E32',
    fontSize: 13,
    fontWeight: '600',
    marginLeft: 7,
  },

  todayCard: {
    width: '100%',
    backgroundColor: '#E9EEDF',
    borderRadius: 25,
    padding: 20,
    borderWidth: 1,
    borderColor: '#D6DEC8',
    elevation: 3,
  },

  todayTop: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  cityArea: {
    flex: 1,
  },

  cityName: {
    fontSize: 21,
    fontWeight: '800',
    color: '#40552F',
  },

  cityState: {
    fontSize: 13,
    color: '#78846F',
    marginTop: 3,
  },

  todayMain: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 14,
  },

  todayTemperature: {
    fontSize: 55,
    fontWeight: '800',
    color: '#354827',
  },

  todayInfo: {
    flex: 1,
    marginLeft: 17,
  },

  todayDescription: {
    fontSize: 17,
    fontWeight: '700',
    color: '#596A4D',
    textTransform: 'capitalize',
  },

  todayFeels: {
    fontSize: 13,
    color: '#7C8873',
    marginTop: 5,
  },

  todayDetails: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F7F8F3',
    borderRadius: 17,
    paddingVertical: 14,
    marginTop: 18,
  },

  todayDetailItem: {
    flex: 1,
    alignItems: 'center',
  },

  todayDetailValue: {
    fontSize: 15,
    fontWeight: '800',
    color: '#46593A',
    marginTop: 4,
  },

  todayDetailLabel: {
    fontSize: 11,
    color: '#7C8874',
    marginTop: 2,
  },

  todayDivider: {
    width: 1,
    height: 48,
    backgroundColor: '#DDE3D3',
  },

  dailyCard: {
    width: '100%',
    minHeight: 88,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 14,
    marginBottom: 11,
    borderWidth: 1,
    borderColor: '#E0E5D8',
    flexDirection: 'row',
    alignItems: 'center',
    elevation: 2,
  },

  dailyDateArea: {
    width: 78,
  },

  dailyDay: {
    fontSize: 14,
    fontWeight: '800',
    color: '#40552F',
  },

  dailyDate: {
    fontSize: 12,
    color: '#7D8973',
    marginTop: 4,
  },

  dailyWeatherArea: {
    flex: 1,
    marginLeft: 12,
  },

  dailyTemperature: {
    fontSize: 17,
    fontWeight: '800',
    color: '#40552F',
  },

  dailyDescription: {
    fontSize: 12,
    color: '#79866F',
    textTransform: 'capitalize',
    marginTop: 3,
  },

  dailyRain: {
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
  },

  dailyRainText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#60798A',
    marginTop: 3,
  },

  shortcuts: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },

  shortcutCard: {
    width: '48%',
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 17,
    borderWidth: 1,
    borderColor: '#E0E5D8',
    elevation: 2,
  },

  shortcutIcon: {
    width: 47,
    height: 47,
    borderRadius: 24,
    backgroundColor: '#E7EDD9',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },

  shortcutTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: '#40552F',
  },

  shortcutText: {
    fontSize: 12,
    color: '#848F7B',
    marginTop: 4,
    lineHeight: 17,
  },

  profileButton: {
  width: 56,
  height: 56,
  borderRadius: 28,
  backgroundColor: '#E5ECD9',
  alignItems: 'center',
  justifyContent: 'center',
  overflow: 'hidden',
  borderWidth: 2,
  borderColor: '#D4DEC5',
},

profileImage: {
  width: '100%',
  height: '100%',
  borderRadius: 28,
},

  footer: {
    fontSize: 12,
    color: '#7A876D',
    textAlign: 'center',
    marginTop: 32,
    marginBottom: 20,
  },
});

export default Style;
