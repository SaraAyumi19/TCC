import React, {
  useCallback,
  useEffect,
  useState,
} from 'react';

import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ScrollView,
  ActivityIndicator,
  StatusBar,
  SafeAreaView,
  Image,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import {
  useNavigation,
  useFocusEffect,
} from '@react-navigation/native';

import AsyncStorage from '@react-native-async-storage/async-storage';

import { supabase } from '../../lib/supabase';

import {
  buscarCidade,
  buscarClimaAtual,
  buscarPrevisao,
  calcularChanceChuvaHoje,
  organizarPrevisaoDiaria,
} from '../../services/clima';

import Style from './style';

export default function Page1() {
  const navigation = useNavigation();

  // ==========================================
  // USUÁRIO
  // ==========================================

  const [name, setName] = useState('');
  const [userId, setUserId] = useState(null);
  const [fotoPerfil, setFotoPerfil] = useState(null);

  // ==========================================
  // SENSOR / IRRIGAÇÃO
  // ==========================================

  const [umidadeSolo, setUmidadeSolo] =
    useState(null);

  const [irrigacao, setIrrigacao] =
    useState('Aguardando conexão');

  const [ultimaLeitura, setUltimaLeitura] =
    useState(null);

  const [ultimoEvento, setUltimoEvento] =
    useState(null);

  const [carregandoSensor, setCarregandoSensor] =
    useState(true);

  const [erroSensor, setErroSensor] =
    useState('');

  // ==========================================
  // CLIMA
  // ==========================================

  const [city, setCity] = useState('');

  const [
    cidadeEncontrada,
    setCidadeEncontrada,
  ] = useState(null);

  const [clima, setClima] = useState(null);

  const [
    previsao,
    setPrevisao,
  ] = useState([]);

  const [loadingUser, setLoadingUser] =
    useState(true);

  const [loadingClima, setLoadingClima] =
    useState(false);

  const [erro, setErro] = useState('');

  // ==========================================
  // SENSOR ID
  // Deve ser igual ao ESP32
  // ==========================================

  const SENSOR_ID = 'sensor_01';

  // ==========================================
  // CARREGAR USUÁRIO
  // ==========================================

  useEffect(() => {
    carregarUsuario();
  }, []);

  // ==========================================
  // CARREGAR DADOS DO SENSOR
  // ==========================================

  useEffect(() => {
    carregarDadosSensor();

    const intervalo = setInterval(() => {
      carregarDadosSensor();
    }, 10000);

    return () => {
      clearInterval(intervalo);
    };
  }, []);

  // ==========================================
  // ATUALIZAR FOTO AO VOLTAR PARA A TELA
  // ==========================================

  useFocusEffect(
    useCallback(() => {
      if (userId) {
        carregarFotoPerfil(userId);
      }

      // Também atualiza os dados do sensor
      carregarDadosSensor();
    }, [userId])
  );

  // ==========================================
  // CARREGAR USUÁRIO
  // ==========================================

  async function carregarUsuario() {
    try {
      const {
        data: { user },
        error,
      } = await supabase.auth.getUser();

      if (error) {
        console.log(
          'Erro ao carregar usuário:',
          error.message
        );

        return;
      }

      if (user) {
        setUserId(user.id);

        const nomeCompleto =
          user.user_metadata?.name || '';

        const primeiroNome =
          nomeCompleto
            .trim()
            .split(' ')[0];

        setName(primeiroNome);

        await carregarFotoPerfil(
          user.id
        );
      }
    } catch (error) {
      console.log(
        'Erro:',
        error
      );
    } finally {
      setLoadingUser(false);
    }
  }

  // ==========================================
  // CARREGAR FOTO
  // ==========================================

  async function carregarFotoPerfil(id) {
    try {
      const imagemSalva =
        await AsyncStorage.getItem(
          `fotoPerfil_${id}`
        );

      setFotoPerfil(
        imagemSalva || null
      );
    } catch (error) {
      console.log(
        'Erro ao carregar foto:',
        error
      );
    }
  }

  // ==========================================
  // CARREGAR DADOS DO SENSOR
  // ==========================================

  async function carregarDadosSensor() {
    try {
      setErroSensor('');

      // ========================================
      // ÚLTIMA LEITURA DE UMIDADE
      // ========================================

      const {
        data: leitura,
        error: erroLeitura,
      } = await supabase
        .from('leituras_umidade')
        .select('*')
        .eq(
          'sensor_id',
          SENSOR_ID
        )
        .order(
          'created_at',
          {
            ascending: false,
          }
        )
        .limit(1)
        .maybeSingle();

      if (erroLeitura) {
        throw erroLeitura;
      }

      // ========================================
      // SE ENCONTROU LEITURA
      // ========================================

      if (leitura) {
        const umidade =
          Number(leitura.umidade);

        setUmidadeSolo(
          Number.isFinite(umidade)
            ? umidade
            : null
        );

        setUltimaLeitura(
          leitura.created_at
        );
      } else {
        setUmidadeSolo(null);
        setUltimaLeitura(null);
      }

      // ========================================
      // ÚLTIMO EVENTO DA BOMBA
      // ========================================

      const {
        data: evento,
        error: erroEvento,
      } = await supabase
        .from('eventos_bomba')
        .select('*')
        .eq(
          'sensor_id',
          SENSOR_ID
        )
        .order(
          'created_at',
          {
            ascending: false,
          }
        )
        .limit(1)
        .maybeSingle();

      if (erroEvento) {
        throw erroEvento;
      }

      // ========================================
      // INTERPRETAR EVENTO
      // ========================================

      if (evento) {
        setUltimoEvento(
          evento.created_at
        );

        if (
          evento.evento === 'ligou'
        ) {
          setIrrigacao(
            'Bomba ligada'
          );
        } else if (
          evento.evento === 'desligou'
        ) {
          setIrrigacao(
            'Bomba desligada'
          );
        } else {
          setIrrigacao(
            evento.evento
          );
        }
      } else {
        setIrrigacao(
          'Aguardando conexão'
        );

        setUltimoEvento(null);
      }

    } catch (error) {
      console.log(
        'Erro ao carregar dados do sensor:',
        error
      );

      setErroSensor(
        error?.message ||
          'Não foi possível carregar os dados do sensor.'
      );
    } finally {
      setCarregandoSensor(false);
    }
  }

  // ==========================================
  // BUSCAR CIDADE
  // ==========================================

  async function searchCity() {
    const cidadeLimpa =
      city.trim();

    if (!cidadeLimpa) {
      setErro(
        'Digite o nome de uma cidade.'
      );

      return;
    }

    try {
      setLoadingClima(true);
      setErro('');
      setCidadeEncontrada(null);
      setClima(null);
      setPrevisao([]);

      const cidade =
        await buscarCidade(
          cidadeLimpa
        );

      setCidadeEncontrada(
        cidade
      );

      const latitude =
        cidade.lat;

      const longitude =
        cidade.lon;

      const weatherData =
        await buscarClimaAtual(
          latitude,
          longitude
        );

      const lista =
        await buscarPrevisao(
          latitude,
          longitude
        );

      const chanceChuvaHoje =
        calcularChanceChuvaHoje(
          lista
        );

      setClima({
        ...weatherData,
        chanceChuva:
          chanceChuvaHoje,
      });

      setPrevisao(
        organizarPrevisaoDiaria(
          lista
        )
      );

    } catch (error) {
      console.log(error);

      setErro(
        error?.message ||
          'Não foi possível buscar os dados do tempo.'
      );
    } finally {
      setLoadingClima(false);
    }
  }

  // ==========================================
  // ÍCONE DO CLIMA
  // ==========================================

  function getIconeClima(
    descricao
  ) {
    const texto =
      descricao?.toLowerCase() ||
      '';

    if (
      texto.includes('tempestade') ||
      texto.includes('trovoada')
    ) {
      return 'thunderstorm-outline';
    }

    if (
      texto.includes('chuva') ||
      texto.includes('garoa')
    ) {
      return 'rainy-outline';
    }

    if (
      texto.includes('nuvem') ||
      texto.includes('nublado')
    ) {
      return 'cloudy-outline';
    }

    if (
      texto.includes('céu limpo') ||
      texto.includes('ceu limpo')
    ) {
      return 'sunny-outline';
    }

    return 'partly-sunny-outline';
  }

  // ==========================================
  // FORMATAR DIA
  // ==========================================

  function formatarDiaSemana(
    dataString
  ) {
    const data = new Date(
      `${dataString}T12:00:00`
    );

    const texto =
      data.toLocaleDateString(
        'pt-BR',
        {
          weekday: 'long',
        }
      );

    return (
      texto.charAt(0).toUpperCase() +
      texto.slice(1)
    );
  }

  // ==========================================
  // FORMATAR DATA
  // ==========================================

  function formatarData(
    dataString
  ) {
    const data = new Date(
      `${dataString}T12:00:00`
    );

    return data.toLocaleDateString(
      'pt-BR',
      {
        day: '2-digit',
        month: '2-digit',
      }
    );
  }

  // ==========================================
  // DATA DA ÚLTIMA LEITURA
  // ==========================================

  function formatarUltimaLeitura() {
    if (!ultimaLeitura) {
      return null;
    }

    try {
      return new Date(
        ultimaLeitura
      ).toLocaleString(
        'pt-BR',
        {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }
      );
    } catch {
      return null;
    }
  }

  // ==========================================
  // RENDER
  // ==========================================

  return (
    <SafeAreaView
      style={Style.safeArea}
    >
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#F4F6EE"
        translucent={false}
      />

      <ScrollView
        style={Style.scroll}
        contentContainerStyle={
          Style.scrollContent
        }
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        nestedScrollEnabled={true}
      >

        {/* =====================================
            HEADER
        ====================================== */}

        <View style={Style.header}>

          <View
            style={
              Style.headerTextArea
            }
          >
            <Text
              style={Style.appName}
            >
              AgroControl
            </Text>

            {loadingUser ? (
              <ActivityIndicator
                size="small"
                color="#536B38"
                style={
                  Style.userLoading
                }
              />
            ) : (
              <Text
                style={Style.hello}
              >
                {name
                  ? `Olá, ${name}!`
                  : 'Olá!'}
              </Text>
            )}
          </View>

          <TouchableOpacity
            style={
              Style.profileButton
            }
            activeOpacity={0.85}
            onPress={() =>
              navigation.navigate(
                'Perfil'
              )
            }
          >
            {fotoPerfil ? (
              <Image
                source={{
                  uri: fotoPerfil,
                }}
                style={
                  Style.profileImage
                }
              />
            ) : (
              <Ionicons
                name="person-outline"
                size={27}
                color="#536B38"
              />
            )}
          </TouchableOpacity>
        </View>

        <Text style={Style.intro}>
          Veja como está sua plantação hoje.
        </Text>

        {/* =====================================
            UMIDADE DO SOLO
        ====================================== */}

        <View
          style={Style.mainCard}
        >
          <View
            style={Style.cardHeader}
          >

            <View
              style={Style.mainIcon}
            >
              <Ionicons
                name="water-outline"
                size={29}
                color="#536B38"
              />
            </View>

            <View
              style={
                Style.cardHeaderText
              }
            >
              <Text
                style={
                  Style.mainCardLabel
                }
              >
                Umidade do solo
              </Text>

              <Text
                style={
                  Style.mainCardDescription
                }
              >
                Leitura do sensor
              </Text>
            </View>
          </View>

          {carregandoSensor ? (

            <View
              style={{
                flexDirection:
                  'row',
                alignItems:
                  'center',
              }}
            >
              <ActivityIndicator
                size="small"
                color="#536B38"
              />

              <Text
                style={[
                  Style.noReading,
                  {
                    marginLeft: 8,
                  },
                ]}
              >
                Carregando leitura...
              </Text>
            </View>

          ) : umidadeSolo === null ? (

            <Text
              style={
                Style.noReading
              }
            >
              Sem leitura disponível
            </Text>

          ) : (

            <Text
              style={
                Style.moistureValue
              }
            >
              {umidadeSolo.toFixed(1)}%
            </Text>

          )}

          {formatarUltimaLeitura() ? (
            <Text
              style={{
                marginTop: 8,
                color: '#7C8576',
                fontSize: 12,
              }}
            >
              Última leitura:{' '}
              {formatarUltimaLeitura()}
            </Text>
          ) : null}
        </View>

        {/* =====================================
            ERRO DO SENSOR
        ====================================== */}

        {erroSensor ? (
          <View
            style={{
              flexDirection:
                'row',
              alignItems:
                'center',
              marginTop: 8,
              marginBottom: 8,
            }}
          >
            <Ionicons
              name="alert-circle-outline"
              size={18}
              color="#8A3E32"
            />

            <Text
              style={{
                marginLeft: 6,
                color: '#8A3E32',
                fontSize: 13,
                flex: 1,
              }}
            >
              {erroSensor}
            </Text>
          </View>
        ) : null}

        {/* =====================================
            IRRIGAÇÃO
        ====================================== */}

        <View
          style={Style.infoCard}
        >

          <View
            style={Style.infoLeft}
          >

            <View
              style={Style.infoIcon}
            >
              <Ionicons
                name="leaf-outline"
                size={25}
                color="#536B38"
              />
            </View>

            <View
              style={
                Style.infoTextArea
              }
            >

              <Text
                style={
                  Style.infoLabel
                }
              >
                Irrigação
              </Text>

              <Text
                style={
                  Style.infoValue
                }
              >
                {irrigacao}
              </Text>

              {ultimoEvento ? (
                <Text
                  style={{
                    fontSize: 11,
                    color: '#8A9285',
                    marginTop: 3,
                  }}
                >
                  Último evento:{' '}
                  {new Date(
                    ultimoEvento
                  ).toLocaleTimeString(
                    'pt-BR',
                    {
                      hour: '2-digit',
                      minute: '2-digit',
                    }
                  )}
                </Text>
              ) : null}

            </View>
          </View>

          <Ionicons
            name={
              irrigacao ===
              'Bomba ligada'
                ? 'water-outline'
                : 'time-outline'
            }
            size={25}
            color={
              irrigacao ===
              'Bomba ligada'
                ? '#536B38'
                : '#7C8576'
            }
          />

        </View>

        {/* =====================================
            CLIMA
        ====================================== */}

        <View
          style={
            Style.sectionHeader
          }
        >
          <Text
            style={
              Style.sectionTitle
            }
          >
            Clima
          </Text>

          <Ionicons
            name="partly-sunny-outline"
            size={26}
            color="#536B38"
          />
        </View>

        <View
          style={Style.weatherCard}
        >

          <View
            style={Style.searchArea}
          >

            <TextInput
              style={
                Style.cityInput
              }
              value={city}
              onChangeText={(text) => {
                setCity(text);

                if (erro) {
                  setErro('');
                }
              }}
              placeholder="Digite sua cidade"
              placeholderTextColor="#919C88"
              autoCapitalize="words"
              returnKeyType="search"
              onSubmitEditing={
                searchCity
              }
              editable={
                !loadingClima
              }
            />

            <TouchableOpacity
              style={[
                Style.searchButton,
                loadingClima &&
                  Style.searchButtonDisabled,
              ]}
              onPress={
                searchCity
              }
              disabled={
                loadingClima
              }
              activeOpacity={0.8}
            >

              {loadingClima ? (

                <ActivityIndicator
                  size="small"
                  color="#FFFFFF"
                />

              ) : (

                <Ionicons
                  name="search"
                  size={23}
                  color="#FFFFFF"
                />

              )}

            </TouchableOpacity>
          </View>

          {erro ? (
            <View
              style={
                Style.errorArea
              }
            >
              <Ionicons
                name="alert-circle-outline"
                size={19}
                color="#8A3E32"
              />

              <Text
                style={
                  Style.errorText
                }
              >
                {erro}
              </Text>
            </View>
          ) : null}

        </View>

        {/* =====================================
            HOJE
        ====================================== */}

        {cidadeEncontrada &&
        clima ? (
          <>

            <View
              style={
                Style.sectionHeader
              }
            >
              <Text
                style={
                  Style.sectionTitle
                }
              >
                Hoje
              </Text>

              <Ionicons
                name={getIconeClima(
                  clima.weather?.[0]
                    ?.description
                )}
                size={27}
                color="#536B38"
              />
            </View>

            <View
              style={
                Style.todayCard
              }
            >

              <View
                style={
                  Style.todayTop
                }
              >

                <View
                  style={
                    Style.cityArea
                  }
                >

                  <Text
                    style={
                      Style.cityName
                    }
                  >
                    {
                      cidadeEncontrada.name
                    }
                  </Text>

                  <Text
                    style={
                      Style.cityState
                    }
                  >
                    {cidadeEncontrada.state ||
                      cidadeEncontrada.country}
                  </Text>

                </View>

                <Ionicons
                  name={getIconeClima(
                    clima.weather?.[0]
                      ?.description
                  )}
                  size={58}
                  color="#536B38"
                />

              </View>

              <View
                style={
                  Style.todayMain
                }
              >

                <Text
                  style={
                    Style.todayTemperature
                  }
                >
                  {Math.round(
                    clima.main.temp
                  )}
                  °C
                </Text>

                <View
                  style={
                    Style.todayInfo
                  }
                >

                  <Text
                    style={
                      Style.todayDescription
                    }
                  >
                    {clima.weather?.[0]
                      ?.description ||
                      'Sem descrição'}
                  </Text>

                  <Text
                    style={
                      Style.todayFeels
                    }
                  >
                    Sensação de{' '}
                    {Math.round(
                      clima.main
                        .feels_like
                    )}
                    °C
                  </Text>

                </View>
              </View>

              <View
                style={
                  Style.todayDetails
                }
              >

                <View
                  style={
                    Style.todayDetailItem
                  }
                >

                  <Ionicons
                    name="water-outline"
                    size={23}
                    color="#60798A"
                  />

                  <Text
                    style={
                      Style.todayDetailValue
                    }
                  >
                    {
                      clima.main
                        .humidity
                    }
                    %
                  </Text>

                  <Text
                    style={
                      Style.todayDetailLabel
                    }
                  >
                    Umidade
                  </Text>

                </View>

                <View
                  style={
                    Style.todayDivider
                  }
                />

                <View
                  style={
                    Style.todayDetailItem
                  }
                >

                  <Ionicons
                    name="rainy-outline"
                    size={23}
                    color="#60798A"
                  />

                  <Text
                    style={
                      Style.todayDetailValue
                    }
                  >
                    {
                      clima.chanceChuva
                    }
                    %
                  </Text>

                  <Text
                    style={
                      Style.todayDetailLabel
                    }
                  >
                    Chuva
                  </Text>

                </View>

                <View
                  style={
                    Style.todayDivider
                  }
                />

                <View
                  style={
                    Style.todayDetailItem
                  }
                >

                  <Ionicons
                    name="speedometer-outline"
                    size={23}
                    color="#60798A"
                  />

                  <Text
                    style={
                      Style.todayDetailValue
                    }
                  >
                    {Math.round(
                      clima.wind
                        ?.speed || 0
                    )}{' '}
                    m/s
                  </Text>

                  <Text
                    style={
                      Style.todayDetailLabel
                    }
                  >
                    Vento
                  </Text>

                </View>

              </View>

            </View>

          </>
        ) : null}

        {/* =====================================
            PRÓXIMOS DIAS
        ====================================== */}

        {previsao.length > 0 ? (
          <>

            <View
              style={
                Style.sectionHeader
              }
            >

              <Text
                style={
                  Style.sectionTitle
                }
              >
                Próximos dias
              </Text>

              <Ionicons
                name="calendar-outline"
                size={24}
                color="#536B38"
              />

            </View>

            {previsao.map(
              (
                previsaoDia,
                index
              ) => {

                const item =
                  previsaoDia.item;

                return (
                  <View
                    key={`${previsaoDia.data}-${index}`}
                    style={
                      Style.dailyCard
                    }
                  >

                    <View
                      style={
                        Style.dailyDateArea
                      }
                    >

                      <Text
                        style={
                          Style.dailyDay
                        }
                      >
                        {formatarDiaSemana(
                          previsaoDia.data
                        )}
                      </Text>

                      <Text
                        style={
                          Style.dailyDate
                        }
                      >
                        {formatarData(
                          previsaoDia.data
                        )}
                      </Text>

                    </View>

                    <Ionicons
                      name={getIconeClima(
                        item.weather?.[0]
                          ?.description
                      )}
                      size={34}
                      color="#536B38"
                    />

                    <View
                      style={
                        Style.dailyWeatherArea
                      }
                    >

                      <Text
                        style={
                          Style.dailyTemperature
                        }
                      >
                        {Math.round(
                          previsaoDia.maxima
                        )}
                        ° /{' '}
                        {Math.round(
                          previsaoDia.minima
                        )}
                        °
                      </Text>

                      <Text
                        style={
                          Style.dailyDescription
                        }
                        numberOfLines={
                          1
                        }
                      >
                        {item.weather?.[0]
                          ?.description ||
                          'Sem descrição'}
                      </Text>

                    </View>

                    <View
                      style={
                        Style.dailyRain
                      }
                    >

                      <Ionicons
                        name="rainy-outline"
                        size={16}
                        color="#60798A"
                      />

                      <Text
                        style={
                          Style.dailyRainText
                        }
                      >
                        {
                          previsaoDia.chuva
                        }
                        %
                      </Text>

                    </View>

                  </View>
                );
              }
            )}

          </>
        ) : null}

        {/* =====================================
            ACESSO RÁPIDO
        ====================================== */}

        <View
          style={
            Style.sectionHeader
          }
        >

          <Text
            style={
              Style.sectionTitle
            }
          >
            Acesso rápido
          </Text>

        </View>

        <ScrollView
          horizontal={true}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={
            Style.shortcuts
          }
          directionalLockEnabled={true}
          bounces={true}
          alwaysBounceHorizontal={true}
          nestedScrollEnabled={true}
        >

          {/* HISTÓRICO */}

          <TouchableOpacity
            style={
              Style.shortcutCard
            }
            activeOpacity={0.85}
            onPress={() =>
              navigation.navigate(
                'Page2'
              )
            }
          >

            <View
              style={
                Style.shortcutIcon
              }
            >
              <Ionicons
                name="stats-chart-outline"
                size={28}
                color="#536B38"
              />
            </View>

            <Text
              style={
                Style.shortcutTitle
              }
            >
              Histórico
            </Text>

            <Text
              style={
                Style.shortcutText
              }
            >
              Consulte seus registros
            </Text>

          </TouchableOpacity>

          {/* ALERTAS */}

          <TouchableOpacity
            style={
              Style.shortcutCard
            }
            activeOpacity={0.85}
            onPress={() =>
              navigation.navigate(
                'Page3'
              )
            }
          >

            <View
              style={
                Style.shortcutIcon
              }
            >
              <Ionicons
                name="notifications-outline"
                size={28}
                color="#536B38"
              />
            </View>

            <Text
              style={
                Style.shortcutTitle
              }
            >
              Alertas
            </Text>

            <Text
              style={
                Style.shortcutText
              }
            >
              Veja seus alertas
            </Text>

          </TouchableOpacity>

          {/* SOBRE NÓS */}

          <TouchableOpacity
            style={
              Style.shortcutCard
            }
            activeOpacity={0.85}
            onPress={() =>
              navigation.navigate(
                'SobreNos'
              )
            }
          >

            <View
              style={
                Style.shortcutIcon
              }
            >
              <Ionicons
                name="leaf-outline"
                size={28}
                color="#536B38"
              />
            </View>

            <Text
              style={
                Style.shortcutTitle
              }
            >
              Sobre nós
            </Text>

            <Text
              style={
                Style.shortcutText
              }
            >
              Conheça o AgroControl
            </Text>

          </TouchableOpacity>

        </ScrollView>

        {/* =====================================
            RODAPÉ
        ====================================== */}

        <Text
          style={Style.footer}
        >
          Simples • Prático • Sustentável
        </Text>

      </ScrollView>
    </SafeAreaView>
  );
}
