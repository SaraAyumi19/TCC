import React, {
  useCallback,
  useEffect,
  useState,
} from 'react';

import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ScrollView,
  ActivityIndicator,
  StatusBar,
  SafeAreaView,
  Image,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';
import {
  useNavigation,
  useFocusEffect,
} from '@react-navigation/native';

import AsyncStorage from '@react-native-async-storage/async-storage';

import { supabase } from '../../lib/supabase';

import {
  buscarCidade,
  buscarClimaAtual,
  buscarPrevisao,
  calcularChanceChuvaHoje,
  organizarPrevisaoDiaria,
} from '../../services/clima';

import Style from './style';

export default function Page1() {
  const navigation = useNavigation();

  const [name, setName] = useState('');
  const [userId, setUserId] = useState(null);
  const [fotoPerfil, setFotoPerfil] = useState(null);

  const [city, setCity] = useState('');

  const [
    cidadeEncontrada,
    setCidadeEncontrada,
  ] = useState(null);

  const [clima, setClima] = useState(null);

  const [previsao, setPrevisao] =
    useState([]);

  const [loadingUser, setLoadingUser] =
    useState(true);

  const [loadingClima, setLoadingClima] =
    useState(false);

  const [erro, setErro] = useState('');

  const umidadeSolo = null;

  const irrigacao =
    'Aguardando conexão';

  useEffect(() => {
    carregarUsuario();
  }, []);

  useFocusEffect(
    useCallback(() => {
      if (userId) {
        carregarFotoPerfil(userId);
      }
    }, [userId])
  );

  async function carregarUsuario() {
    try {
      const {
        data: { user },
        error,
      } = await supabase.auth.getUser();

      if (error) {
        console.log(error.message);
        return;
      }

      if (user) {
        setUserId(user.id);

        const nomeCompleto =
          user.user_metadata?.name || '';

        const primeiroNome =
          nomeCompleto
            .trim()
            .split(' ')[0];

        setName(primeiroNome);

        await carregarFotoPerfil(
          user.id
        );
      }
    } catch (error) {
      console.log(error);
    } finally {
      setLoadingUser(false);
    }
  }

  async function carregarFotoPerfil(id) {
    try {
      const imagemSalva =
        await AsyncStorage.getItem(
          `fotoPerfil_${id}`
        );

      setFotoPerfil(
        imagemSalva || null
      );
    } catch (error) {
      console.log(error);
    }
  }

  async function searchCity() {
    const cidadeLimpa =
      city.trim();

    if (!cidadeLimpa) {
      setErro(
        'Digite o nome de uma cidade.'
      );

      return;
    }

    try {
      setLoadingClima(true);
      setErro('');
      setCidadeEncontrada(null);
      setClima(null);
      setPrevisao([]);

      const cidade =
        await buscarCidade(
          cidadeLimpa
        );

      setCidadeEncontrada(
        cidade
      );

      const latitude =
        cidade.lat;

      const longitude =
        cidade.lon;

      const weatherData =
        await buscarClimaAtual(
          latitude,
          longitude
        );

      const lista =
        await buscarPrevisao(
          latitude,
          longitude
        );

      const chanceChuvaHoje =
        calcularChanceChuvaHoje(
          lista
        );

      setClima({
        ...weatherData,
        chanceChuva:
          chanceChuvaHoje,
      });

      setPrevisao(
        organizarPrevisaoDiaria(
          lista
        )
      );
    } catch (error) {
      console.log(error);

      setErro(
        error?.message ||
          'Não foi possível buscar os dados do tempo.'
      );
    } finally {
      setLoadingClima(false);
    }
  }

  function getIconeClima(
    descricao
  ) {
    const texto =
      descricao?.toLowerCase() ||
      '';

    if (
      texto.includes(
        'tempestade'
      ) ||
      texto.includes(
        'trovoada'
      )
    ) {
      return 'thunderstorm-outline';
    }

    if (
      texto.includes('chuva') ||
      texto.includes('garoa')
    ) {
      return 'rainy-outline';
    }

    if (
      texto.includes('nuvem') ||
      texto.includes('nublado')
    ) {
      return 'cloudy-outline';
    }

    if (
      texto.includes(
        'céu limpo'
      ) ||
      texto.includes(
        'ceu limpo'
      )
    ) {
      return 'sunny-outline';
    }

    return 'partly-sunny-outline';
  }

  function formatarDiaSemana(
    dataString
  ) {
    const data = new Date(
      `${dataString}T12:00:00`
    );

    const texto =
      data.toLocaleDateString(
        'pt-BR',
        {
          weekday: 'long',
        }
      );

    return (
      texto.charAt(0).toUpperCase() +
      texto.slice(1)
    );
  }

  function formatarData(
    dataString
  ) {
    const data = new Date(
      `${dataString}T12:00:00`
    );

    return data.toLocaleDateString(
      'pt-BR',
      {
        day: '2-digit',
        month: '2-digit',
      }
    );
  }

  return (
    <SafeAreaView
      style={Style.safeArea}
    >
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#F4F6EE"
        translucent={false}
      />

      <ScrollView
        style={Style.scroll}
        contentContainerStyle={
          Style.scrollContent
        }
        showsVerticalScrollIndicator={
          true
        }
        keyboardShouldPersistTaps="handled"
        nestedScrollEnabled
      >
        <View style={Style.header}>
          <View
            style={
              Style.headerTextArea
            }
          >
            <Text
              style={Style.appName}
            >
              AgroControl
            </Text>

            {loadingUser ? (
              <ActivityIndicator
                size="small"
                color="#536B38"
                style={
                  Style.userLoading
                }
              />
            ) : (
              <Text
                style={Style.hello}
              >
                {name
                  ? `Olá, ${name}!`
                  : 'Olá!'}
              </Text>
            )}
          </View>

          <TouchableOpacity
            style={
              Style.profileButton
            }
            activeOpacity={0.85}
            onPress={() =>
              navigation.navigate(
                'Perfil'
              )
            }
          >
            {fotoPerfil ? (
              <Image
                source={{
                  uri: fotoPerfil,
                }}
                style={
                  Style.profileImage
                }
              />
            ) : (
              <Ionicons
                name="person-outline"
                size={27}
                color="#536B38"
              />
            )}
          </TouchableOpacity>
        </View>

        <Text style={Style.intro}>
          Veja como está sua plantação hoje.
        </Text>

        <View style={Style.mainCard}>
          <View
            style={Style.cardHeader}
          >
            <View
              style={Style.mainIcon}
            >
              <Ionicons
                name="water-outline"
                size={29}
                color="#536B38"
              />
            </View>

            <View
              style={
                Style.cardHeaderText
              }
            >
              <Text
                style={
                  Style.mainCardLabel
                }
              >
                Umidade do solo
              </Text>

              <Text
                style={
                  Style.mainCardDescription
                }
              >
                Leitura do sensor
              </Text>
            </View>
          </View>

          {umidadeSolo === null ? (
            <Text
              style={
                Style.noReading
              }
            >
              Sem leitura disponível
            </Text>
          ) : (
            <Text
              style={
                Style.moistureValue
              }
            >
              {umidadeSolo}%
            </Text>
          )}
        </View>

        <View
          style={Style.infoCard}
        >
          <View
            style={Style.infoLeft}
          >
            <View
              style={Style.infoIcon}
            >
              <Ionicons
                name="leaf-outline"
                size={25}
                color="#536B38"
              />
            </View>

            <View
              style={
                Style.infoTextArea
              }
            >
              <Text
                style={
                  Style.infoLabel
                }
              >
                Irrigação
              </Text>

              <Text
                style={
                  Style.infoValue
                }
              >
                {irrigacao}
              </Text>
            </View>
          </View>

          <Ionicons
            name="time-outline"
            size={25}
            color="#7C8576"
          />
        </View>

        <View
          style={
            Style.sectionHeader
          }
        >
          <Text
            style={
              Style.sectionTitle
            }
          >
            Clima
          </Text>

          <Ionicons
            name="partly-sunny-outline"
            size={26}
            color="#536B38"
          />
        </View>

        <View
          style={Style.weatherCard}
        >
          <View
            style={Style.searchArea}
          >
            <TextInput
              style={Style.cityInput}
              value={city}
              onChangeText={(text) => {
                setCity(text);

                if (erro) {
                  setErro('');
                }
              }}
              placeholder="Digite sua cidade"
              placeholderTextColor="#919C88"
              autoCapitalize="words"
              returnKeyType="search"
              onSubmitEditing={
                searchCity
              }
              editable={
                !loadingClima
              }
            />

            <TouchableOpacity
              style={[
                Style.searchButton,
                loadingClima &&
                  Style.searchButtonDisabled,
              ]}
              onPress={searchCity}
              disabled={
                loadingClima
              }
              activeOpacity={0.8}
            >
              {loadingClima ? (
                <ActivityIndicator
                  size="small"
                  color="#FFFFFF"
                />
              ) : (
                <Ionicons
                  name="search"
                  size={23}
                  color="#FFFFFF"
                />
              )}
            </TouchableOpacity>
          </View>

          {erro ? (
            <View
              style={Style.errorArea}
            >
              <Ionicons
                name="alert-circle-outline"
                size={19}
                color="#8A3E32"
              />

              <Text
                style={
                  Style.errorText
                }
              >
                {erro}
              </Text>
            </View>
          ) : null}
        </View>

        {cidadeEncontrada &&
        clima ? (
          <>
            <View
              style={
                Style.sectionHeader
              }
            >
              <Text
                style={
                  Style.sectionTitle
                }
              >
                Hoje
              </Text>

              <Ionicons
                name={getIconeClima(
                  clima.weather?.[0]
                    ?.description
                )}
                size={27}
                color="#536B38"
              />
            </View>

            <View
              style={Style.todayCard}
            >
              <View
                style={Style.todayTop}
              >
                <View
                  style={
                    Style.cityArea
                  }
                >
                  <Text
                    style={
                      Style.cityName
                    }
                  >
                    {
                      cidadeEncontrada.name
                    }
                  </Text>

                  <Text
                    style={
                      Style.cityState
                    }
                  >
                    {cidadeEncontrada.state ||
                      cidadeEncontrada.country}
                  </Text>
                </View>

                <Ionicons
                  name={getIconeClima(
                    clima.weather?.[0]
                      ?.description
                  )}
                  size={58}
                  color="#536B38"
                />
              </View>

              <View
                style={Style.todayMain}
              >
                <Text
                  style={
                    Style.todayTemperature
                  }
                >
                  {Math.round(
                    clima.main.temp
                  )}
                  °C
                </Text>

                <View
                  style={
                    Style.todayInfo
                  }
                >
                  <Text
                    style={
                      Style.todayDescription
                    }
                  >
                    {clima.weather?.[0]
                      ?.description ||
                      'Sem descrição'}
                  </Text>

                  <Text
                    style={
                      Style.todayFeels
                    }
                  >
                    Sensação de{' '}
                    {Math.round(
                      clima.main
                        .feels_like
                    )}
                    °C
                  </Text>
                </View>
              </View>

              <View
                style={
                  Style.todayDetails
                }
              >
                <View
                  style={
                    Style.todayDetailItem
                  }
                >
                  <Ionicons
                    name="water-outline"
                    size={23}
                    color="#60798A"
                  />

                  <Text
                    style={
                      Style.todayDetailValue
                    }
                  >
                    {
                      clima.main
                        .humidity
                    }
                    %
                  </Text>

                  <Text
                    style={
                      Style.todayDetailLabel
                    }
                  >
                    Umidade
                  </Text>
                </View>

                <View
                  style={
                    Style.todayDivider
                  }
                />

                <View
                  style={
                    Style.todayDetailItem
                  }
                >
                  <Ionicons
                    name="rainy-outline"
                    size={23}
                    color="#60798A"
                  />

                  <Text
                    style={
                      Style.todayDetailValue
                    }
                  >
                    {
                      clima.chanceChuva
                    }
                    %
                  </Text>

                  <Text
                    style={
                      Style.todayDetailLabel
                    }
                  >
                    Chuva
                  </Text>
                </View>

                <View
                  style={
                    Style.todayDivider
                  }
                />

                <View
                  style={
                    Style.todayDetailItem
                  }
                >
                  <Ionicons
                    name="speedometer-outline"
                    size={23}
                    color="#60798A"
                  />

                  <Text
                    style={
                      Style.todayDetailValue
                    }
                  >
                    {Math.round(
                      clima.wind
                        ?.speed || 0
                    )}{' '}
                    m/s
                  </Text>

                  <Text
                    style={
                      Style.todayDetailLabel
                    }
                  >
                    Vento
                  </Text>
                </View>
              </View>
            </View>
          </>
        ) : null}

        {previsao.length > 0 ? (
          <>
            <View
              style={
                Style.sectionHeader
              }
            >
              <Text
                style={
                  Style.sectionTitle
                }
              >
                Próximos dias
              </Text>

              <Ionicons
                name="calendar-outline"
                size={24}
                color="#536B38"
              />
            </View>

            {previsao.map(
              (
                previsaoDia,
                index
              ) => {
                const item =
                  previsaoDia.item;

                return (
                  <View
                    key={`${previsaoDia.data}-${index}`}
                    style={
                      Style.dailyCard
                    }
                  >
                    <View
                      style={
                        Style.dailyDateArea
                      }
                    >
                      <Text
                        style={
                          Style.dailyDay
                        }
                      >
                        {formatarDiaSemana(
                          previsaoDia.data
                        )}
                      </Text>

                      <Text
                        style={
                          Style.dailyDate
                        }
                      >
                        {formatarData(
                          previsaoDia.data
                        )}
                      </Text>
                    </View>

                    <Ionicons
                      name={getIconeClima(
                        item.weather?.[0]
                          ?.description
                      )}
                      size={34}
                      color="#536B38"
                    />

                    <View
                      style={
                        Style.dailyWeatherArea
                      }
                    >
                      <Text
                        style={
                          Style.dailyTemperature
                        }
                      >
                        {Math.round(
                          previsaoDia.maxima
                        )}
                        ° /{' '}
                        {Math.round(
                          previsaoDia.minima
                        )}
                        °
                      </Text>

                      <Text
                        style={
                          Style.dailyDescription
                        }
                        numberOfLines={
                          1
                        }
                      >
                        {item.weather?.[0]
                          ?.description ||
                          'Sem descrição'}
                      </Text>
                    </View>

                    <View
                      style={
                        Style.dailyRain
                      }
                    >
                      <Ionicons
                        name="rainy-outline"
                        size={16}
                        color="#60798A"
                      />

                      <Text
                        style={
                          Style.dailyRainText
                        }
                      >
                        {
                          previsaoDia.chuva
                        }
                        %
                      </Text>
                    </View>
                  </View>
                );
              }
            )}
          </>
        ) : null}

        <View
          style={
            Style.sectionHeader
          }
        >
          <Text
            style={
              Style.sectionTitle
            }
          >
            Acesso rápido
          </Text>
        </View>

        <View
          style={Style.shortcuts}
        >
          <TouchableOpacity
            style={
              Style.shortcutCard
            }
            activeOpacity={0.85}
            onPress={() =>
              navigation.navigate(
                'Page2'
              )
            }
          >
            <View
              style={
                Style.shortcutIcon
              }
            >
              <Ionicons
                name="stats-chart-outline"
                size={28}
                color="#536B38"
              />
            </View>

            <Text
              style={
                Style.shortcutTitle
              }
            >
              Histórico
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={
              Style.shortcutCard
            }
            activeOpacity={0.85}
            onPress={() =>
              navigation.navigate(
                'Page3'
              )
            }
          >
            <View
              style={
                Style.shortcutIcon
              }
            >
              <Ionicons
                name="notifications-outline"
                size={28}
                color="#536B38"
              />
            </View>

            <Text
              style={
                Style.shortcutTitle
              }
            >
              Alertas
            </Text>
          </TouchableOpacity>
        </View>

        <Text style={Style.footer}>
          Simples • Prático • Sustentável
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}
