import {
  StyleSheet,
} from "react-native";

export const colors = {
  background: "#F5EFE3",

  beige: "#E8DDCB",
  beigeLight: "#F8F3EA",

  brown: "#6B5848",
  brownDark: "#3D3026",

  green: "#526B45",
  greenDark: "#3F5535",
  greenLight: "#DDE7D5",

  white: "#FFFFFF",

  gray: "#777777",
  grayLight: "#E2DDD5",

  red: "#B94A48",
};

const Style = StyleSheet.create({

  // =========================================
  // GERAL
  // =========================================

  container: {
    flex: 1,
    backgroundColor:
      colors.background,
  },

  content: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },

  // =========================================
  // HEADER
  // =========================================

  header: {
    height: 85,

    paddingHorizontal: 18,

    paddingTop: 20,

    flexDirection: "row",

    alignItems: "center",

    justifyContent:
      "space-between",

    backgroundColor:
      colors.beige,
  },

  titulo: {
    fontSize: 22,

    fontWeight: "bold",

    color:
      colors.brownDark,
  },

  headerButton: {
    width: 45,
    height: 45,

    borderRadius: 23,

    backgroundColor:
      colors.beigeLight,

    alignItems: "center",

    justifyContent: "center",
  },

  perfilButton: {
    width: 48,
    height: 48,

    borderRadius: 24,

    backgroundColor:
      colors.beigeLight,

    borderWidth: 2,

    borderColor:
      colors.green,

    alignItems: "center",

    justifyContent: "center",

    overflow: "hidden",
  },

  fotoPerfil: {
    width: 44,
    height: 44,

    borderRadius: 22,
  },

  // =========================================
  // MENU
  // =========================================

  modalFundo: {
    flex: 1,

    backgroundColor:
      "rgba(61,48,38,0.35)",
  },

  menuContainer: {
    width: 230,

    marginTop: 65,

    marginLeft: 15,

    paddingVertical: 10,

    backgroundColor:
      colors.white,

    borderRadius: 20,

    elevation: 6,
  },

  menuTitulo: {
    fontSize: 20,

    fontWeight: "bold",

    color:
      colors.brownDark,

    paddingHorizontal: 18,

    paddingVertical: 12,
  },

  menuItem: {
    padding: 16,

    flexDirection: "row",

    alignItems: "center",
  },

  menuTexto: {
    marginLeft: 12,

    fontSize: 16,

    color:
      colors.brownDark,
  },

  // =========================================
  // INPUT
  // =========================================

  input: {
    width: "100%",

    height: 52,

    backgroundColor:
      colors.white,

    borderRadius: 15,

    paddingHorizontal: 16,

    fontSize: 16,

    color:
      colors.brownDark,

    borderWidth: 1,

    borderColor:
      colors.beige,
  },

  // =========================================
  // BOTÃO
  // =========================================

  button: {
    height: 52,

    backgroundColor:
      colors.green,

    borderRadius: 15,

    alignItems: "center",

    justifyContent: "center",

    paddingHorizontal: 25,

    marginTop: 12,
  },

  buttonText: {
    color:
      colors.white,

    fontSize: 16,

    fontWeight: "bold",
  },

  // =========================================
  // CARD
  // =========================================

  card: {
    backgroundColor:
      colors.white,

    borderRadius: 22,

    padding: 20,

    marginTop: 20,

    elevation: 3,
  },

  cardTitulo: {
    fontSize: 22,

    fontWeight: "bold",

    color:
      colors.brownDark,

    marginBottom: 8,
  },

  // =========================================
  // LOGIN / CADASTRO
  // =========================================

  authContainer: {
    flex: 1,

    backgroundColor:
      colors.background,

    justifyContent:
      "center",

    paddingHorizontal: 25,
  },

  logo: {
    alignItems: "center",

    marginBottom: 35,
  },

  logoTexto: {
    fontSize: 32,

    fontWeight: "bold",

    color:
      colors.greenDark,
  },

  logoSubtexto: {
    marginTop: 5,

    fontSize: 15,

    color:
      colors.brown,
  },

  authInput: {
    width: "100%",

    height: 52,

    backgroundColor:
      colors.white,

    borderRadius: 15,

    paddingHorizontal: 16,

    marginBottom: 12,

    borderWidth: 1,

    borderColor:
      colors.beige,
  },

  link: {
    textAlign: "center",

    color:
      colors.greenDark,

    fontWeight: "bold",

    marginTop: 18,
  },

  erro: {
    color:
      colors.red,

    textAlign: "center",

    marginBottom: 10,
  },

  // =========================================
  // PERFIL
  // =========================================

  perfilContainer: {
    flex: 1,

    backgroundColor:
      colors.background,
  },

  perfilContent: {
    alignItems: "center",

    paddingHorizontal: 25,

    paddingTop: 30,
  },

  fotoGrande: {
    width: 130,
    height: 130,

    borderRadius: 65,

    backgroundColor:
      colors.beige,

    borderWidth: 4,

    borderColor:
      colors.green,
  },

  fotoPlaceholder: {
    width: 130,
    height: 130,

    borderRadius: 65,

    backgroundColor:
      colors.beige,

    borderWidth: 4,

    borderColor:
      colors.green,

    alignItems: "center",

    justifyContent: "center",
  },

  trocarFoto: {
    marginTop: 12,

    color:
      colors.greenDark,

    fontWeight: "bold",
  },

  perfilNome: {
    fontSize: 25,

    fontWeight: "bold",

    color:
      colors.brownDark,

    marginTop: 15,
  },

  perfilEmail: {
    color:
      colors.gray,

    marginTop: 5,

    marginBottom: 25,
  },

  label: {
    width: "100%",

    color:
      colors.brown,

    fontWeight: "bold",

    marginBottom: 6,

    marginTop: 10,
  },

  // =========================================
  // PREVISÃO
  // =========================================

  previsaoItem: {
    backgroundColor:
      colors.white,

    padding: 15,

    marginBottom: 10,

    borderRadius: 16,

    borderWidth: 1,

    borderColor:
      colors.grayLight,
  },

  previsaoTopo: {
    flexDirection: "row",

    justifyContent:
      "space-between",

    alignItems: "center",
  },

  temperatura: {
    fontSize: 28,

    fontWeight: "bold",

    color:
      colors.greenDark,
  },

});

export default Style;