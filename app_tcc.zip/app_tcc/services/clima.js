const API_KEY =
  'e0a40fe2984aaeec66defdc668107d65';

export async function buscarCidade(nomeCidade) {
  const cidade = nomeCidade.trim();

  if (!cidade) {
    throw new Error('Digite o nome de uma cidade.');
  }

  const url =
    'https://api.openweathermap.org/geo/1.0/direct' +
    `?q=${encodeURIComponent(cidade)},BR` +
    '&limit=1' +
    `&appid=${API_KEY}`;

  const response = await fetch(url);
  const data = await response.json();

  if (!response.ok) {
    throw new Error(
      data?.message ||
        'Não foi possível buscar a cidade.'
    );
  }

  if (!data?.length) {
    throw new Error('Cidade não encontrada.');
  }

  return data[0];
}

export async function buscarClimaAtual(
  latitude,
  longitude
) {
  const url =
    'https://api.openweathermap.org/data/2.5/weather' +
    `?lat=${latitude}` +
    `&lon=${longitude}` +
    `&appid=${API_KEY}` +
    '&units=metric' +
    '&lang=pt_br';

  const response = await fetch(url);
  const data = await response.json();

  if (!response.ok) {
    throw new Error(
      data?.message ||
        'Não foi possível buscar o clima.'
    );
  }

  return data;
}

export async function buscarPrevisao(
  latitude,
  longitude
) {
  const url =
    'https://api.openweathermap.org/data/2.5/forecast' +
    `?lat=${latitude}` +
    `&lon=${longitude}` +
    `&appid=${API_KEY}` +
    '&units=metric' +
    '&lang=pt_br';

  const response = await fetch(url);
  const data = await response.json();

  if (!response.ok) {
    throw new Error(
      data?.message ||
        'Não foi possível buscar a previsão.'
    );
  }

  return data?.list || [];
}

export function calcularChanceChuvaHoje(lista) {
  return Math.round(
    Math.max(
      0,
      ...lista
        .slice(0, 8)
        .map((item) => item.pop || 0)
    ) * 100
  );
}

export function organizarPrevisaoDiaria(lista) {
  const grupos = {};

  lista.forEach((item) => {
    const data = new Date(item.dt * 1000);

    const chave =
      data.getFullYear() +
      '-' +
      String(data.getMonth() + 1).padStart(
        2,
        '0'
      ) +
      '-' +
      String(data.getDate()).padStart(
        2,
        '0'
      );

    if (!grupos[chave]) {
      grupos[chave] = [];
    }

    grupos[chave].push(item);
  });

  const hoje = new Date();

  const chaveHoje =
    hoje.getFullYear() +
    '-' +
    String(hoje.getMonth() + 1).padStart(
      2,
      '0'
    ) +
    '-' +
    String(hoje.getDate()).padStart(
      2,
      '0'
    );

  return Object.entries(grupos)
    .filter(([data]) => data !== chaveHoje)
    .slice(0, 4)
    .map(([data, itens]) => {
      let representativo = itens[0];

      itens.forEach((item) => {
        const hora = new Date(
          item.dt * 1000
        ).getHours();

        const horaAtual = new Date(
          representativo.dt * 1000
        ).getHours();

        if (
          Math.abs(hora - 12) <
          Math.abs(horaAtual - 12)
        ) {
          representativo = item;
        }
      });

      const minima = Math.min(
        ...itens.map(
          (item) => item.main.temp_min
        )
      );

      const maxima = Math.max(
        ...itens.map(
          (item) => item.main.temp_max
        )
      );

      const chuva = Math.round(
        Math.max(
          ...itens.map(
            (item) => item.pop || 0
          )
        ) * 100
      );

      return {
        data,
        item: representativo,
        minima,
        maxima,
        chuva,
      };
    });
}
