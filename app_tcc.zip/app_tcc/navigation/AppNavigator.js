import React from "react";

import {
  NavigationContainer,
} from "@react-navigation/native";

import {
  createStackNavigator,
} from "@react-navigation/stack";

import Login from "../screens/Login";
import Cadastro from "../screens/Cadastro";
import Page1 from "../screens/Page1";
import Page2 from "../screens/Page2";
import Page3 from "../screens/Page3";
import Perfil from "../screens/Perfil";

const Stack = createStackNavigator();

export default function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Login"
        screenOptions={{
          headerShown: false,
        }}
      >
        <Stack.Screen
          name="Login"
          component={Login}
        />

        <Stack.Screen
          name="Cadastro"
          component={Cadastro}
        />

        <Stack.Screen
          name="Page1"
          component={Page1}
        />

        <Stack.Screen
          name="Page2"
          component={Page2}
        />

        <Stack.Screen
          name="Page3"
          component={Page3}
        />

        <Stack.Screen
          name="Perfil"
          component={Perfil}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}