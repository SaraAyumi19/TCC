import React from 'react';

import { createStackNavigator } from '@react-navigation/stack';

import Page1 from '../screens/Page1/Page1';
import Page2 from '../screens/Page2';
import Page3 from '../screens/Page3';
import Perfil from '../screens/Perfil';
import DadosPessoais from '../screens/DadosPessoais';

const Stack = createStackNavigator();

export default function AppNavigator() {
  return (
    <Stack.Navigator
      initialRouteName="Page1"
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen
        name="Page1"
        component={Page1}
      />
      <Stack.Screen
        name="Page2"
        component={Page2}
      />
      
<Stack.Screen
        name="Page3"
        component={Page3}
      />
      <Stack.Screen
        name="Perfil"
        component={Perfil}
      />
      <Stack.Screen
        name="DadosPessoais"
        component={DadosPessoais}
      />
    </Stack.Navigator>
  );
}