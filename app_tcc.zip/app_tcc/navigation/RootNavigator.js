import React, { useEffect, useState } from 'react';

import {
  View,
  ActivityIndicator,
} from 'react-native';

import {
  NavigationContainer,
} from '@react-navigation/native';

import AuthNavigator from './AuthNavigator';
import AppNavigator from './AppNavigator';

import { supabase } from '../lib/supabase';

export default function RootNavigator() {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let ativo = true;

    async function carregarSessao() {
      try {
        const {
          data: { session },
          error,
        } = await supabase.auth.getSession();

        if (error) {
          console.log(
            'Erro ao carregar sessão:',
            error.message
          );
        }

        if (ativo) {
          setSession(session);
        }

      } catch (error) {
        console.log(
          'Erro ao verificar sessão:',
          error
        );

      } finally {
        if (ativo) {
          setLoading(false);
        }
      }
    }

    carregarSessao();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(
      (_event, novaSession) => {
        if (ativo) {
          setSession(novaSession);
          setLoading(false);
        }
      }
    );

    return () => {
      ativo = false;

      if (subscription) {
        subscription.unsubscribe();
      }
    };
  }, []);

  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: '#D9E2C3',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <ActivityIndicator
          size="large"
          color="#536B38"
        />
      </View>
    );
  }

  return (
    <NavigationContainer>
      {session ? (
        <AppNavigator />
      ) : (
        <AuthNavigator />
      )}
    </NavigationContainer>
  );
}